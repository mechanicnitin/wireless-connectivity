# Network Architecture — Consolidated Reference

## Scope

The source material describes a workplace/branch network modernization covering LAN, Wi-Fi, NAC and WAN/SD-WAN.

## Major technology domains

- **LAN:** Cisco Catalyst switching, including C9300L access and C9500 distribution/core patterns.
- **Wireless:** Juniper Mist AP-based cloud-managed WLAN.
- **NAC / identity:** ForeScout CounterACT is described as an authentication/enforcement component in the LAN/Wi-Fi design.
- **SD-WAN/WAN:** Palo Alto Prisma SD-WAN ION platforms with multiple WAN/carriage options.
- **Management/assurance:** Cisco DNA Center, Mist Cloud and other monitoring/management integrations are referenced.
- **Service dependencies:** DHCP, DNS, authentication/AAA, WAN and security services are integral to end-to-end client connectivity.

## High-level client connectivity model

For a wireless client, the expected dependency chain is broadly:

`Client → AP/WLAN → Authentication/AAA → LAN/VLAN → DHCP → DNS → Gateway/WAN → Application`

A troubleshooting workflow should identify the first failed dependency rather than assuming that a client connectivity symptom is itself the root cause.

## Site models

The source documentation distinguishes multiple site types, including:

- Large administrative sites
- Medium/large branch patterns
- Small/retail branch patterns
- Other specialized site models

Use the relevant site-design document for the site being investigated.

## Important design principle

The knowledge base describes the **intended design**. MCP data describes the **current operational state**. They should be used together, not substituted for one another.
