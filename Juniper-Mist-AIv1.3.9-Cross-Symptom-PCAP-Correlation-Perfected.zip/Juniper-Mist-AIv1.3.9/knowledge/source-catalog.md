# Knowledge Source Catalog

The following source groups were reviewed to prepare this knowledge layer.

## Core agent skills
- `.agents/skills/357c-large-site-design/SKILL.md` — **357c-large-site-design** — 357 Collins Street large admin site detailed design. Use when answering questions about 357C site topology, VLANs, IP addressing, VRFs, BGP routing, ION 9200 configuration, security zones (Blue/Purple/Red/Orange), HA design, path policies, QoS policies, wireless (Mist AP45), switch port assignments, circuit configuration (TID/NBN/MPLS), NAT policies, ZBFW security rules, or migration plans for CBA large admin sites. Keywords: 357C, 357 Collins, large site, L1A, L2A, ION 9200, C9500, C9300L, Mist AP45, VRF, eBGP, VLAN, SDWAN, Prisma, Palo Alto, CBA, admin site, detailed design.
- `.agents/skills/435-DNS-troubleshooting/SKILL.md` — **435-DNS-troubleshooting** — DNS resolution checker for the 435 Bourke Street (435B) office network. Use when a user wants to test DNS reachability for CBA internal or external URLs, identify which hostnames cannot be resolved from the current network, audit DNS server configuration, or troubleshoot name resolution issues at 435B. Runs a parallel Python script against a known URL inventory and produces a Markdown report in wiki/. Keywords: DNS, resolve, 435B, 435 Bourke, hostname, nslookup, name resolution, internal URLs, external URLs, DNS server, DNS troubleshooting, reachability, connectivity.
- `.agents/skills/435b-large-site-design/SKILL.md` — **435b-large-site-design** — 435 Bourke Street large admin site detailed design. Use when answering questions about 435B site topology, VLANs, IP addressing, VRFs, BGP routing, ION 9200 configuration, security zones (Blue/Purple/Brown/Red/Orange), HA design, path policies, QoS policies, wireless (Mist AP47 Wi-Fi 7), switch port assignments, circuit configuration (TID/Optus Evolve/MPLS), NAT policies, ZBFW security rules, Mist Edge DevntstWifi, EX4650/EX4400 Juniper switch configuration, user personas (EPZ/BWA), Mist site/device IDs, SCM element/site IDs, AP inventory, or migration plans for CBA 435 Bourke Street. Keywords: 435B, 435 Bourke, large site, L2A, ION 9200, EX4650, EX4400, Mist AP47, VRF, eBGP, VLAN, SDWAN, Prisma, Palo Alto, CBA, admin site, detailed design, Juniper, Wi-Fi 7, Mist Edge, WorkplaceWiFi, CanWiFi, DevntstWifi, cbvc435b, site_id, element_id, device_id, d872d7fd, 1763356464382023636.
- `.agents/skills/435b-migration-testing/SKILL.md` — **435b-migration-testing** — 435 Bourke Street migration connectivity testing procedures. Use when the user needs to run, interpret, or troubleshoot connectivity tests at 435B during WBT migration phases. Covers the 435b_test.py script usage, floor-level gateway lookup, parallel ping/traceroute test interpretation, compact Markdown report generation, expected packet loss thresholds, WiFi vs LAN detection, and Windows vs macOS test commands. Keywords: 435B, 435 Bourke, migration test, ping, traceroute, tracert, tcptrace, packet loss, VRRP gateway, Brown zone, floor test, connectivity test, WBT testing, 357C, WiFi, LAN.
- `.agents/skills/branch-connectivity-check/SKILL.md` — **branch-connectivity-check** — On-demand SD-WAN NBN/TID connectivity check for CBA WBT. Use when a user asks to check SD-WAN connectivity, refresh sites and see which sites are on partial connectivity, find out whether NBN or TID is down per site, check which sites have recovered, or cross-reference partial sites against Jira tickets. Covers Branch, BBC, and Admin/Corporate sites, assessing ONLY NBN/TID carriers (MPLS excluded — a site whose only down link is MPLS is treated as healthy). Produces a date+time-stamped Markdown page in wiki/branch_connectivty/ and, on request, publishes it to Confluence under parent 1545812593. Files new tickets under epic BC1-70 for Branch and BBC sites (Admin sites are report-only), deduping against a known-open-tickets registry. Keywords: branch connectivity, bbc connectivity, admin site connectivity, partial connectivity, NBN down, TID down, which circuit down, refresh sites, recovered sites, single WAN path, connectivity check.
- `.agents/skills/branch-network-troubleshooting/SKILL.md` — **branch-network-troubleshooting** — Branch and device lookup index for CBA SDWAN migrations. Use this skill to find the correct branch data file given a BSB number, site code, device hostname, management IP address, or branch location name. Covers ION appliances, Cisco switches, and all migration site data.
- `.agents/skills/daily-435b-monitoring/SKILL.md` — **daily-435b-monitoring** — Daily monitoring workflow for the 435 Bourke Street large admin office. Use when the user asks to check 435B health, monitor 435B, generate a 435B report, or investigate 435B issues. Combines SCM (ION HA pair PSR01/PSR02), Mist (Juniper distribution + access fleet), Netmetrics (Prometheus time-series — bandwidth, errors, flaps, probes, scrape health), and PagerDuty into a single corporate-office hygiene check. Produces a timestamped Markdown report in wiki/daily_435b_monitoring/. Keywords: 435B, 435 Bourke, Bourke Street, daily 435B, 435B health, PSR01, PSR02, DS01, DS02, jasa1, jasb1, irb.22, Brown VRF, top talker, tunnel down, HA failover, scrape health.
- `.agents/skills/daily-hygiene/SKILL.md` — **daily-hygiene** — Daily network health check workflow for CBA WBT branch infrastructure. Use when a user asks to check network health, run daily hygiene, generate a health report, or investigate active issues across SCM (Palo Alto Prisma SD-WAN), Mist (Juniper switching), and PagerDuty. Produces a timestamped Markdown report in wiki/daily_hygiene/, publishes it to Confluence, and files Jira tickets (parent BC1-70) for eligible Branch and BBC (Business Banking Centre) critical and partial-connectivity/link-down issues after checking for existing tickets. Keywords: daily hygiene, health check, network health, morning check, daily report, alarms, incidents, SCM, Mist, PagerDuty, tunnel down, link degraded, site down, switch down, flapping, SLE, confluence, jira.
- `.agents/skills/dnac-hygiene/SKILL.md` — **dnac-hygiene** — DNAC (Cisco DNA Center) daily hygiene check workflow for the CBA WBT wired Catalyst fleet. Use when a user asks to run dnac hygiene, check DNAC health, audit DNAC compliance, generate a DNAC report, or investigate unreachable Catalyst devices, NSW site health, P1 Assurance issues, EOX/PSIRT/IMAGE drift, or core/distribution status. Produces a timestamped Markdown report in wiki/dnac_daily_hygiene/. This skill is currently in a validation period — run it standalone for several days before integrating it into the broader daily-hygiene rollup. Keywords: dnac hygiene, dnac health, catalyst, cisco DNA center, unreachable devices, compliance, EOX, PSIRT, IMAGE drift, site health, assurance issues, core, distribution, access switch.
- `.agents/skills/ion-cli-clear-commands/SKILL.md` — **ion-cli-clear-commands** — >
- `.agents/skills/ion-cli-config-commands/SKILL.md` — **ion-cli-config-commands** — >
- `.agents/skills/ion-cli-debug-commands/SKILL.md` — **ion-cli-debug-commands** — >
- `.agents/skills/ion-cli-dump-commands/SKILL.md` — **ion-cli-dump-commands** — >
- `.agents/skills/ion-cli-inspect-commands/SKILL.md` — **ion-cli-inspect-commands** — >
- `.agents/skills/lan-high-level-design/SKILL.md` — **lan-high-level-design** — Comprehensive technical reference for the CBA Workplace Branch & Admin LAN, WiFi, and NAC High Level Design. Covers site models, switching, routing, VRF segmentation, security zones, DNA Center, Juniper Mist WiFi, ForeScout NAC, and all management services.
- `.agents/skills/on-call-investigation/SKILL.md` — **on-call-investigation** — On-call PagerDuty incident investigation and triage workflow. Use when a user says they are on call, wants to check their PagerDuty incidents, investigate open alerts, triage incidents, or create/update a daily on-call wiki page. Fetches the user's personal PD incidents, investigates each using LinkIQ MCP tools (SCM, Mist, PagerDuty), groups related incidents, produces root cause analysis, and writes actionable remediation steps with PagerDuty links. Updates wiki/daily_hygiene/YYYY-MM-DD.md incrementally — safe to run multiple times per day. Keywords: on call, on-call, pagerduty, PD, incidents, investigate, triage, my incidents, assigned to me, check alerts, incident investigation, root cause, remediation, wiki.
- `.agents/skills/overview-and-general-information/SKILL.md` — **overview-and-general-information** — This document overviews the whole project, file structures, commands and their outputs. ,
- `.agents/skills/sdwan-hld-overview/SKILL.md` — **sdwan-hld-overview** — >
- `.agents/skills/site-connectivity-troubleshooting/SKILL.md` — **site-connectivity-troubleshooting** — Site WAN connectivity triage for CBA branches and BBCs. Use when a user asks 'is <site> up?', 'check connectivity at <site>', '<site> is down', '<site> is offline', 'WAN down at <site>', 'which Telstra number do I call for <site>?', 'show me down circuits at <site>', or asks to investigate down WAN links at a site (BSB, site_code, hostname, or location name). For each down circuit the skill reports carrier, FNN/circuit reference, mapped ION port, the support phone number with IVR path, the site address, and ready-to-read talking points for the carrier. Cross-references branch-network-troubleshooting (site lookup, address, FNN inventory) and support-escalation (carrier phones, IVR, required info). Keywords: site connectivity, WAN down, link down, NBN down, MPLS down, TID down, circuit down, who do I call, carrier contact, FNN, fault reference, branch outage, BBC outage, site offline.
- `.agents/skills/small-sites-detailed-design/SKILL.md` — **small-sites-detailed-design** — CBA small branch site (retail branch) detailed design. Use when answering questions about small site topology (S1A/S1B/S1C/S2A/S2B/S3A), VLANs, IP addressing, VRF segmentation (Blue/Purple/Red/Global), ION 1200-C-5G-WW configuration, security zones, path policies, QoS policies, wireless (Mist AP45), switch port assignments, circuit configuration (TID/NBN TC4/4G-5G cellular), NAT policies, ZBFW security rules, DNAC integration, Cisco C9300L switch configuration, Layer 2/Layer 3 design, DHCP services, migration plans, or LAN device management for CBA small branch sites. Keywords: small site, branch site, F-type, S1A, S1B, S1C, S2A, S2B, S3A, ION 1200, C9300L, Mist AP45, VRF, VLAN, SDWAN, Prisma, Palo Alto, CBA, retail branch, detailed design, WBT, Workplace Branch Transformation.
- `.agents/skills/sns-wiki/SKILL.md` — **sns-wiki** — >
- `.agents/skills/support-escalation/SKILL.md` — **support-escalation** — Support contacts and escalation procedures for CBA WBT branch network issues. Use when a user needs to contact a carrier (Telstra TID, NBN, 4G/5G, Optus), device vendor (Palo Alto for ION, Cisco for switches), or CBA internal teams (Property, EUX SPG) for support. Covers phone numbers, IVR paths, what information to gather before calling, how to raise a Palo Alto TAC case, and decision logic for which team to contact based on the issue type. Keywords: support, escalation, contact, phone, call, Telstra, NBN, TID, Palo Alto, TAC, Cisco, Optus, CBA Property, carrier, vendor, helpdesk, fault, outage, raise case, lodge ticket.

## Design/source documents
- `assets/357c_DD/02-1-Document-Overview.md`
- `assets/357c_DD/03-2-Requirements.md`
- `assets/357c_DD/04-3-Large-Site-Design-Overview.md`
- `assets/357c_DD/05-4-Large-Site-–-Layer-1-(Physical-Topology).md`
- `assets/357c_DD/06-5-Large-Site-–-Layer-2.md`
- `assets/357c_DD/07-6-Large-Site-–-Layer-3.md`
- `assets/357c_DD/08-7-Large-Site---Standardized-LAN-Device-Configuration.md`
- `assets/357c_DD/09-8-Large-Site-–-ION-Policy-Design.md`
- `assets/357c_DD/10-9-Large-Site-–-Wireless-Design.md`
- `assets/357c_DD/11-10-Large-Site-–-NAC-Design.md`
- `assets/357c_DD/12-11-DNAC-Integration.md`
- `assets/357c_DD/13-12-Migration-Plan.md`
- `assets/357c_DD/14-Appendix-A.-Environmental-Requirements.md`
- `assets/357c_DD/15-13-Large-Site-–-Environmental.md`
- `assets/ION_CLI/07-Clear-Commands.md`
- `assets/ION_CLI/08-Config-Commands.md`
- `assets/ION_CLI/09-Debug-Commands.md`
- `assets/ION_CLI/10-Dump-Commands.md`
- `assets/ION_CLI/11-Inspect-Commands.md`
- `assets/LAN_HLD/05-6-Solution-Summary.md`
- `assets/LAN_HLD/06-7-Architecture-Decisions.md`
- `assets/LAN_HLD/07-8-Current-Solution-Overview---Workplace-LAN,-WiFi,-and-NAC.md`
- `assets/LAN_HLD/08-9-Solution.md`
- `assets/LAN_HLD/09-10-Cisco-Devices-Administration-Access.md`
- `assets/LAN_HLD/10-11-CBA-NMS-Integration.md`
- `assets/LAN_HLD/11-Appendix-A.-Site-Type-Definitions.md`
- `assets/LAN_HLD/12-Appendix-B.-DNA-Centre-Design.md`
- `assets/LAN_HLD/13-Appendix-C.-WIFI-Design.md`
- `assets/LAN_HLD/14-Appendix-D.-NAC-Design.md`
- `assets/SDWAN-HLD/03-Executive-Summary.md`
- `assets/SDWAN-HLD/04-Architectural-Decisions.md`
- `assets/SDWAN-HLD/05-Constraints.md`
- `assets/SDWAN-HLD/06-Risks.md`
- `assets/SDWAN-HLD/07-Current-WAN-Design.md`
- `assets/SDWAN-HLD/08-Palo-Alto-SDWAN-Technology-Review.md`
- `assets/SDWAN-HLD/09-SDWAN-Design.md`
- `assets/SDWAN-HLD/10-Security.md`
- `assets/SDWAN-HLD/11-QoS-and-Application-Based-Routing-Policies.md`
- `assets/SDWAN-HLD/12-Centralised-Management-and-Monitoring.md`
- `assets/SDWAN-HLD/13-Document-Acceptance.md`
- `assets/small_site_DD/02-1-Document-Overview.md`
- `assets/small_site_DD/03-2-Requirements.md`
- `assets/small_site_DD/04-3-Small-Site-Design-Overview.md`
- `assets/small_site_DD/05-4-Small-Site-–-Layer-1-(Physical-Topology).md`
- `assets/small_site_DD/06-5-Small-Site-–-Layer-2.md`
- `assets/small_site_DD/07-6-Small-Site-–-Layer-3.md`
- `assets/small_site_DD/08-7-Small-Site---Standardized-LAN-Device-Configuration.md`
- `assets/small_site_DD/09-8-Small-Site-–-ION-Policy-Design.md`
- `assets/small_site_DD/10-9-Small-Site-–-Wireless-Design.md`
- `assets/small_site_DD/11-10-Small-Site-–-NAC-Design.md`
- `assets/small_site_DD/12-11-DNAC-Integration.md`
- `assets/small_site_DD/13-12-Migration-Plan.md`
- `assets/small_site_DD/14-13-Small-Site-–-Environmental.md`

## Wiki / operational material
The repository contains a large `wiki/` tree. These files are primarily operational reports, daily checks, incidents and historical findings. They should feed the future Memory/Operations layer rather than be merged wholesale into static architecture knowledge.
- Wiki Markdown files reviewed in inventory: 137

## Important source categories intentionally kept separate
- `.agents/skills/**/SKILL.md`: procedure/behavior instructions → Step 3 Skills, not static knowledge.
- `wiki/`: incidents, daily checks and historical outputs → future Step 7 Memory/Operations.
- `assets/ION_CLI/`: command references → Skills/Playbooks, not network topology knowledge.
- Branch resource files: detailed site/device data → site-specific knowledge/inventory when needed.
- JSON/CSV inventories: structured operational data → inventory/data source, not broad narrative knowledge.
