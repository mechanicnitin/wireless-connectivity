---
name: marvis-inspired-investigation-model
version: 1.3.4
description: Observable Juniper Mist troubleshooting concepts used to make the MCP orchestration more systematic. This is methodology, not a copy of proprietary Marvis internals.
---

# Marvis-Inspired Investigation Model

## Purpose

Use documented Juniper Mist operational concepts as a reference for structuring investigations performed from the Juniper Mist MCP.

This document does **not** claim access to or reproduction of proprietary Marvis models, hidden prompts, internal ranking algorithms, or internal API logic.

## Observable model from Juniper documentation

Juniper documentation describes Marvis conversational troubleshooting as able to work with natural-language requests about sites, devices, clients and applications, and describes structured query concepts such as COUNT, LIST, RANK, LOCATE and TROUBLESHOOT. It also describes Wireless SLEs, classifiers, timelines, affected-device views, AP/WLAN/device-type concentration and client/AP event detail.

## Useful orchestration pattern

1. Establish the symptom and scope.
2. Establish the actual time window.
3. Use SLEs/events to identify affected populations and time periods.
4. Drill into client/AP events.
5. Correlate by AP, WLAN, device type, radio/band, site and shared dependencies.
6. Inspect the relevant failure classifier/sub-classifier.
7. Compare affected and healthy populations.
8. Use timelines to establish temporal causality.
9. Produce a root-cause hypothesis with evidence and uncertainty.

## Important distinction

Marvis/VNA output can be used as a second opinion when separately available. The Juniper Mist MCP remains the operational source of truth for the orchestrator's own claims.

## Current-environment policy

IPv6/DHCPv6 is not used in this environment. Do not include it in wireless RCA unless explicitly requested.
