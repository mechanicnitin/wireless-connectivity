# Juniper Mist Wireless — Knowledge Reference

## Source basis

Derived from the LAN HLD wireless design and related wireless sections in the site-design documentation.

## Architecture

The documented wireless modernization uses:

- Juniper Mist AP45 Wi-Fi 6/6E access points
- Mist Cloud for monitoring, configuration and management
- Integration with existing NAC/authentication services
- Enterprise corporate WLAN using 802.1X/WPA3 Enterprise
- Guest WLAN using WPA3-MPSK in the documented design
- Integration with broader monitoring/event-management platforms

## Wireless dependency chain

For a client connectivity investigation, use this conceptual chain:

`Client → AP association → WLAN → Authentication/AAA → VLAN → DHCP → DNS → Gateway/WAN → Application`

## What to correlate with MCP

When live Mist data is available, correlate:

- Client association state
- AP health
- Client authentication state
- SLEs
- Alarms/alerts
- Recent changes
- WLAN/SSID context
- Client IP/DHCP state
- AP/site scope
- Time window of the incident

## Scope logic

- One client affected → start with client/AP/authentication-specific evidence.
- Many clients on one AP/area → investigate AP/RF/local infrastructure.
- Many APs/clients affected at one site → investigate site-level dependencies.
- Multiple sites affected → investigate shared services, WAN, authentication or other centralized dependencies.

These are investigation heuristics, not proof of root cause; current MCP evidence must confirm them.
