# SD-WAN / WAN Architecture

## Source basis

Derived from the SD-WAN HLD, small/large site designs and the existing SD-WAN HLD agent skill.

## Architecture themes

The source material describes:

- Palo Alto Prisma SD-WAN ION platforms
- Branch and administrative WAN connectivity
- Internet, NBN, cellular and other carrier services depending on site
- Redundant/active-active or primary/backup patterns depending on site model
- Centralized management and monitoring
- Routing, QoS, security and application-based path policies

## Branch connectivity

A branch outage investigation should distinguish:

1. Physical/carrier circuit state
2. ION WAN interface state
3. SD-WAN path/tunnel state
4. Routing state
5. LAN-side reachability
6. Application/service reachability

## Troubleshooting principle

A site being unreachable does not automatically mean the LAN is down. Determine whether the failure is on:

`Carrier → WAN edge → SD-WAN overlay → Routing/VRF → LAN → Service`

Use the site-specific design to identify expected primary/backup paths.
