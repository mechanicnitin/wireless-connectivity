# Network Service Dependencies

## Authentication / AAA / NAC

The design material references ForeScout CounterACT and enterprise authentication flows.

For a wireless authentication problem, distinguish:

- Client/AP association failure
- Authentication rejection
- Authentication timeout/no response
- NAC/policy enforcement issue
- RADIUS/AAA service availability
- Network reachability to authentication infrastructure

## DHCP

DHCP is a dependency after successful network access/authentication.

For a client with no usable IP address, determine:

- Whether authentication completed
- Which VLAN/segment the client should use
- Whether DHCP relay/helper is expected
- Whether the relevant DHCP scope exists
- Whether the DHCP service is reachable
- Whether the client received an address

## DNS

DNS becomes relevant once the client has usable IP connectivity.

Distinguish:

- No IP address
- Gateway/connectivity failure
- DNS server reachability failure
- Name resolution failure
- Application-specific resolution failure

## End-to-end rule

Do not jump directly to DNS or application troubleshooting if an earlier dependency—association, authentication, VLAN or DHCP—is already failing.
