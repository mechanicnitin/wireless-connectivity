# Operational Context

## Source basis

The repository contains skills and wiki material for:

- Daily hygiene monitoring
- 435B monitoring
- DNAC hygiene
- Branch connectivity checks
- Site connectivity troubleshooting
- On-call investigation
- Support escalation
- Migration testing
- DNS troubleshooting

## Current-state rule

Use live MCP telemetry for current operational status.

Static documentation should answer:

- What should the design look like?
- What dependencies exist?
- What is the expected topology?
- What is the expected service flow?

Live MCP should answer:

- What is happening now?
- Which devices/APs/clients are currently affected?
- What alarms/SLEs/events are currently present?
- What changed recently?

## Escalation context

The repository contains support/escalation information. Keep vendor contact details and other operationally sensitive data in the existing controlled source files rather than duplicating them into broad AI knowledge summaries unless explicitly required.

## Daily hygiene

Daily hygiene outputs and incident reports are operational history, not static architecture knowledge. They should eventually feed the Memory/Operations layer rather than being copied wholesale into `knowledge.md`.
