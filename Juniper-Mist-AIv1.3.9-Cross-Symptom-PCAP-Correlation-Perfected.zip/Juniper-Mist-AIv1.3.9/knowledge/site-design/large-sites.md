# Large Site Design

## Source basis

Derived from the 357C/large-site detailed design and the existing large-site agent skills.

## General model

The large-site design describes:

- Cisco C9300L access switching
- Cisco C9500 core/distribution switching
- Fibre uplinks between access and distribution/core
- Palo Alto Prisma SD-WAN ION platforms at the WAN edge
- Multiple WAN/carriage options
- Multiple wireless APs per floor based on coverage and capacity requirements

## Layering

The design is organized around:

- Physical topology
- Layer 2 switching
- Layer 3 routing/segmentation
- Standardized LAN device configuration
- SD-WAN/ION policies
- Wireless design
- NAC
- DNAC integration
- Migration and environmental requirements

## Troubleshooting implication

For a large-site incident, determine whether the symptom is:

- Local to one client
- Local to one AP
- Local to one floor/area
- Related to access switching
- Related to distribution/core
- Related to authentication/NAC
- Site-wide
- WAN/SD-WAN related

The site-specific HLD/LLD should be consulted before interpreting topology-dependent symptoms.
