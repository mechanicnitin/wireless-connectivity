# Small Site Design

## Source basis

Derived from the Small Site Detailed Design and the existing `small-sites-detailed-design` agent skill.

## General model

Small sites are described as retail/branch sites using:

- Palo Alto Prisma SD-WAN ION 1200-C-5G-WW
- Cisco C9300L access switching
- A collapsed core/distribution/access pattern at smaller sites
- Additional access switches where required
- WAN connectivity based on combinations of TID, NBN and cellular services depending on site type

## Site variants

The source design defines multiple small-site variants, including S1A/S1B/S1C and S2A/S2B-style configurations. Always consult the detailed design for the exact site variant before making a device/topology assumption.

## Layer 2

The design includes:

- 802.1Q trunking between access switching and the ION
- Explicit VLAN allow-lists on trunks
- A dedicated native VLAN convention
- Dedicated VLANs for data, voice, wireless and AP management
- Separate transit/underlay VLANs for the SD-WAN edge design

## Layer 3

The small-site design includes:

- Multiple VRFs/segmentation domains
- ION-based routing between relevant VRFs
- WAN connectivity through the ION
- SVI-based LAN gatewaying
- DHCP and other network services integrated into the design

## Wireless

Small sites use Juniper Mist APs in the documented wireless architecture. Wireless client troubleshooting should therefore correlate Mist client/AP state with the underlying VLAN, DHCP, authentication and WAN design.

## Troubleshooting implication

For a small-site wireless issue, identify:

1. Site type
2. AP and WLAN
3. Client association state
4. Authentication state
5. Assigned VLAN
6. DHCP/IP state
7. DNS/gateway reachability
8. WAN state

Do not assume the same topology exists at every small site.
