# WBC Network AI — Knowledge Base

## Purpose

This directory contains **static network knowledge and design context** for the AI assistant.

The authoritative live operational state should come from the connected network/Mist MCP. This knowledge base provides the architecture and environment context needed to interpret that live data correctly.

## Knowledge hierarchy

1. `architecture/` — overall LAN/Wi-Fi/NAC architecture and design principles
2. `site-design/` — small/large site design patterns and site models
3. `wireless/` — Juniper Mist wireless design and WLAN context
4. `sdwan/` — WAN/Prisma SD-WAN architecture and dependencies
5. `services/` — DHCP, DNS, RADIUS/NAC and other service dependencies
6. `operations/` — operational conventions, monitoring and troubleshooting context
7. `inventory/` — pointers/indexes to site/device information; detailed inventories should remain in their dedicated source files

## Source-of-truth rules

- **Current state:** query MCP/live telemetry.
- **Static design:** use this knowledge base.
- **Troubleshooting procedure:** use Skills/Playbooks, not this directory.
- **Past incidents / lessons learned:** use Memory.
- Never infer a current outage from static documentation alone.
- If documentation conflicts with live telemetry, report the conflict and prefer current telemetry for current-state questions.

## Site context

When a query identifies a site, first identify its site model and load the relevant site-design information before interpreting device or client telemetry.

## Update process

1. Add or update source-backed information in the appropriate knowledge file.
2. Keep design facts separate from troubleshooting procedures.
3. Record source document paths in `source-catalog.md`.
4. Review for obsolete architecture before promoting information to the final knowledge base.
