#!/usr/bin/env python3
"""Safely retrieve and validate a Juniper Mist MCP-provided PCAP URL.

Usage:
  python3 tools-download-pcap.py '<pcap_url>' /tmp/incident.pcap

The exact URL must come from MCP. The script intentionally never prints the URL.
It accepts application/octet-stream because Mist capture download endpoints may
return generic binary content types.
"""
import os, sys, tempfile, urllib.parse, urllib.request

MAX_BYTES = int(os.getenv("MIST_PCAP_MAX_BYTES", str(250 * 1024 * 1024)))
TIMEOUT = int(os.getenv("MIST_PCAP_TIMEOUT", "30"))

MAGICS = {
    bytes.fromhex("d4c3b2a1"), bytes.fromhex("a1b2c3d4"),
    bytes.fromhex("4d3cb2a1"), bytes.fromhex("a1b23c4d"),
    bytes.fromhex("0a0d0d0a"),
}

def main():
    if len(sys.argv) != 3:
        print("usage: tools-download-pcap.py '<pcap_url>' <output_path>", file=sys.stderr)
        return 2
    url, output = sys.argv[1], sys.argv[2]
    p = urllib.parse.urlparse(url)
    if p.scheme != "https" or not p.hostname:
        print("ERROR: URL must be HTTPS with a hostname", file=sys.stderr); return 2
    if not p.query:
        print("ERROR: expected a signed/query-bearing MCP capture URL", file=sys.stderr); return 2

    # The orchestrator may supply an environment allowlist. Without one, use the
    # exact host from MCP; callers should enforce their network egress policy too.
    allowed = {x.strip().lower() for x in os.getenv("MIST_PCAP_ALLOWED_HOSTS", "").split(",") if x.strip()}
    if allowed and p.hostname.lower() not in allowed:
        print("ERROR: host is not in MIST_PCAP_ALLOWED_HOSTS", file=sys.stderr); return 3

    req = urllib.request.Request(url, headers={"Accept": "application/octet-stream,*/*"}, method="GET")
    fd, tmp = tempfile.mkstemp(prefix="mist-pcap-", suffix=".download")
    os.close(fd)
    total = 0
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r, open(tmp, "wb") as f:
            while True:
                chunk = r.read(1024 * 1024)
                if not chunk: break
                total += len(chunk)
                if total > MAX_BYTES:
                    raise RuntimeError("capture exceeds MIST_PCAP_MAX_BYTES")
                f.write(chunk)
        with open(tmp, "rb") as f:
            magic = f.read(4)
        if magic not in MAGICS:
            print("ERROR: HTTP retrieval succeeded but file is not recognized as PCAP/PCAPNG", file=sys.stderr)
            return 4
        os.makedirs(os.path.dirname(os.path.abspath(output)) or ".", exist_ok=True)
        os.chmod(tmp, 0o600)
        os.replace(tmp, output)
        print(f"RETRIEVED_AND_VALIDATED bytes={total} output={output}")
        return 0
    except Exception as e:
        print(f"REFERENCE_RETURNED_NOT_RETRIEVED: {type(e).__name__}: {e}", file=sys.stderr)
        return 5
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

if __name__ == "__main__":
    raise SystemExit(main())
