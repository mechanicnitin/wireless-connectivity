---
name: wireless-troubleshooting-entry
description: Route a wireless incident to focused playbooks only after broad evidence collection and first-failure classification.
---

# Wireless Troubleshooting Entry Playbook

## Purpose

This is the routing layer between the parent wireless investigation skill and focused playbooks.

## Rule

Do not select a playbook solely from the user's wording. First perform the broad wireless investigation across all relevant domains and identify the incident window, earliest confirmed failure, and scope. Focused playbooks are a second-stage deep dive, not a replacement for broad correlation.

The symptom can trigger multiple playbooks. For example, "slow" may require RF/performance plus network-path or authentication correlation.

## Routing

Association failure → `association-failure.md`

Authentication/authorization failure → `authentication-failure.md`

No IPv4 address after successful authentication → `dhcp-failure.md`

DNS/name-resolution failure after IPv4 connectivity → `dns-failure.md`

AP down/unreachable → `ap-down.md`

AP wired-path issue → `ap-switchport.md`

Repeated client disconnects → `client-disconnection.md`

RF/performance degradation → `rf-performance.md`

Client slowness/poor performance/high ping → `client-performance.md`

Voice/meeting quality degradation → `voice-quality.md`

## Packet-capture escalation

If the broad investigation returns an incident event with `pcap_urls`, load `orchestrator/pcap-analysis.md` after the event/timeline attribution gate. PCAP analysis is an evidence layer shared by all symptom types; it is not a replacement for the focused playbook.

## Execution

1. Complete the broad baseline defined by `orchestrator/investigation-engine.md`.
2. Identify the incident window, first confirmed failure, scope, and material data gaps.
3. Load the selected playbook(s).
4. Collect only missing evidence required by the selected playbook decision logic.
5. Compare against site knowledge.
6. Re-check scope and first confirmed failure after the deep dive.
7. Rank RCA and confidence.
8. Return to the orchestrator for final synthesis.

## Environment rule

IPv6/DHCPv6 is out of scope because this environment is IPv4-only, unless explicitly requested.
