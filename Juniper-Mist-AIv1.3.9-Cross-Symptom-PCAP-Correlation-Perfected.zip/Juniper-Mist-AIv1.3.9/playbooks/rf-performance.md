---
name: rf-performance
description: Diagnose wireless performance degradation using RF metrics, SLEs, client comparisons and AP context.
---

# RF Performance Playbook

## Trigger
Use when clients report poor performance, low throughput, high retries, poor signal, or RF-related SLE degradation.

## Required Evidence
- Client/AP/site
- RSSI
- SNR
- Channel
- Channel utilization
- Retry/retransmission indicators
- PHY/rate information
- Neighbor/AP context
- Relevant SLEs
- Scope of impact
- Recent RF/configuration changes

## Procedure
1. Confirm the symptom is performance/RF related.
2. Identify affected clients/APs.
3. Compare affected and healthy clients.
4. Analyze RSSI/SNR together.
5. Analyze channel utilization and retries.
6. Check PHY/rate behavior.
7. Check neighboring AP/RF context.
8. Determine scope.
9. Check AP health and wired path if multiple clients are affected.
10. Correlate recent changes.

## Decision Logic
Single client abnormal → client/RF behavior.
Many clients on AP abnormal → AP/RF environment.
Many APs area-wide → RF/environment/deployment.
Site-wide → investigate shared infrastructure in addition to RF.

Do not diagnose RF from one metric.


## Automatic PCAP escalation

When a relevant MCP event exposes `pcap_url`/`pcap_urls`, automatically invoke `orchestrator/pcap-analysis.md` after attribution. Do not wait for a follow-up prompt. If retrieval is blocked, record the retrieval limitation and continue the playbook. If the operator later attaches the capture, analyze it as the same incident evidence.
