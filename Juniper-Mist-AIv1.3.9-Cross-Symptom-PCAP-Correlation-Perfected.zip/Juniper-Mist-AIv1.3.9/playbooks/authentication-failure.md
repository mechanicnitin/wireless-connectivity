---
name: authentication-failure
description: Diagnose wireless client authentication failures after successful association.
---

# Authentication Failure Playbook

## Trigger
Use when association succeeds but authentication fails, times out, is rejected, or repeatedly drops during authentication.

## Objective
Identify whether the failure is client-specific, AP/SSID-specific, RADIUS/AAA-related, policy-related, or broader.

## Required Evidence
- Client MAC/identity
- AP, site and SSID
- Authentication events and timestamps
- Failure/reject/timeout reason
- RADIUS/AAA response where available
- Relevant SLEs, alarms and alerts
- Affected-client scope
- Recent WLAN/security/RADIUS/NAC changes

## Automatic deep comparison

Before RCA, automatically compare the affected attempt with peer-AP successes, same-AP healthy clients, and same-client success/failure pairs. If a `pcap_url` is present, trigger automatic PCAP retrieval and analysis; do not wait for a second prompt.

## Procedure
1. Confirm association succeeded.
2. Confirm authentication is the first failed stage.
3. Review authentication event timeline.
4. Identify exact failure reason.
5. Check RADIUS/AAA response or availability.
6. Determine scope:
   - One client → client credentials/device/policy path
   - Multiple clients on one AP → AP/SSID/AP-path investigation
   - Multiple APs → shared WLAN/AAA/NAC investigation
   - Site-wide → shared services/policy investigation
7. Correlate timestamps with recent changes.
8. Check DHCP only after authentication succeeds.

## Decision Logic
Reject → investigate identity, credentials, policy and authorization.
Timeout/no response → investigate RADIUS/AAA reachability and service health.
Multiple clients affected → prioritize shared AAA/NAC dependencies.
Unknown reason → report evidence gap; do not invent RCA.

## Output
Authentication summary, scope, evidence, confirmed failure point, likely RCA, recommended action, confidence, data gaps, next playbook.

## Controlled-test rule

If the suspect AP was replaced or moved, quarantine replacement-generated reboot/disconnect/configuration events from AP-fault scoring and evaluate the identity-versus-location experiment first.

## Evidence Rules
Never claim RADIUS failure without evidence. Distinguish observed response from inferred cause.

## AP-specific entry-path differential

For a named client or suspect AP, do not stop at the triggering failure. Automatically compare the failed authentication attempt with: (1) the same client's successful authentication on peer APs, (2) successful/long-established clients on the suspect AP, and (3) successful and failed attempts on the suspect AP. Include previous AP, association/reassociation, FT/11r, PMF, `auth_type`, RADIUS server/outcome, EAP events, RSSI and timestamps when exposed.

If full EAP fails on the suspect AP but succeeds on peer APs using the same WLAN/RADIUS infrastructure, report strong AP-specific authentication-path evidence. Do not convert this directly into an internal AP mechanism.

If an authentication event exposes `pcap_urls`, correlate the capture with the exact client/AP/timestamp and inspect EAPOL/802.1X, RSN/PMF and FT frames where visible. Use `orchestrator/pcap-analysis.md`; do not infer missing RADIUS-side packets from a client-side capture.

