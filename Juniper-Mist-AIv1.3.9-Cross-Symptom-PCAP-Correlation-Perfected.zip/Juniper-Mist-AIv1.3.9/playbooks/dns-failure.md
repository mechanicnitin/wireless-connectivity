---
name: dns-failure
description: Diagnose DNS failures after successful IP assignment and basic network connectivity.
---

# DNS Failure Playbook

## Trigger
Use when the client has a valid IP and basic connectivity but name resolution fails.

## Preconditions
Confirm:
- Association successful
- Authentication successful
- DHCP/IP assignment successful
- Basic gateway/network connectivity is available

If a precondition fails, return to the appropriate earlier playbook.

## Required Evidence
- Client IP/subnet
- DNS server information where available
- DNS resolution symptoms
- Relevant events/SLEs
- Scope of impact
- Site/service dependency information

## Procedure
1. Verify valid IP.
2. Verify gateway/basic connectivity.
3. Identify expected DNS service.
4. Check DNS reachability where available.
5. Determine whether failures affect one client, VLAN, site or multiple sites.
6. Check recent DNS/network changes.
7. Separate DNS failure from application/service failure.

## Scope Logic
One client → client configuration/path.
One VLAN/site → local DNS or network dependency.
Multiple sites → shared DNS service/dependency.

## Packet-capture escalation

If the relevant DNS/connectivity event exposes `pcap_urls`, use `orchestrator/pcap-analysis.md` to correlate DNS request/response timing and failures with the exact incident window. Do not use a nearby capture as proof of DNS failure.

## Output
DNS summary, prerequisites, evidence, failure point, likely RCA, recommended action, confidence and data gaps.

## Evidence Rules
Do not classify an application failure as DNS without DNS-specific evidence.


## Automatic PCAP escalation

When a relevant MCP event exposes `pcap_url`/`pcap_urls`, automatically invoke `orchestrator/pcap-analysis.md` after attribution. Do not wait for a follow-up prompt. If retrieval is blocked, record the retrieval limitation and continue the playbook. If the operator later attaches the capture, analyze it as the same incident evidence.
