---
name: client-performance
description: Focused playbook for wireless slowness, latency, poor throughput, intermittent performance, or degraded user experience after connectivity is established.
---

# Client Performance Playbook

## Purpose
Use when the client is connected but the user reports slowness/poor performance.

## Do not assume

"Slow" is not automatically RF, DHCP, DNS, WAN, or application latency.

## Collect and correlate

1. Actual incident period and duration.
2. Client throughput/rates where available.
3. RSSI/SNR and retry/retransmission indicators.
4. Channel utilization/interference.
5. AP client count/load and radio health.
6. Roaming/reassociation/deauthentication around slow periods.
7. DHCP latency/retries only when reconnect/renewal overlaps the symptom.
8. ARP/gateway/connectivity indicators.
9. DNS failures/latency where available.
10. WLAN/site SLEs and classifiers.
11. Affected vs healthy clients on the same AP/WLAN.
12. AP wired path and uplink health when evidence suggests packet loss/congestion.
13. Recent changes.

## Packet-capture escalation

If the incident event exposes `pcap_urls`, correlate the capture with the symptom window and use `orchestrator/pcap-analysis.md` for packet loss, retransmission, timing, DHCP/ARP/ICMP or other relevant packet facts. Do not treat a PCAP from a nearby event as proof of the slow period unless timestamps overlap.

## Root-cause discipline

A metric is a **candidate contributor**, not a root cause, only if it is temporally aligned and technically capable of explaining the symptom. Sustained application slowness cannot be proven from wireless telemetry alone when application/packet-level evidence is unavailable.

Examples:
- weak RSSI can be a contributor when supported by low SNR/retries/rate degradation or roaming behavior
- DHCP latency can explain reconnect delay but not necessarily sustained application slowness
- RADIUS delay can explain connection/roam delay but not sustained post-auth throughput
- DNS failure can explain name-resolution delay but not raw link throughput

## Output

Separate:
- confirmed failure(s)
- confirmed contributors (directly evidenced)
- likely contributors
- downstream symptoms
- ruled-out/weakened domains
- unknowns/data gaps
- minimum next test

Never present reconnect overhead, DHCP/RADIUS latency, weak RF, or DNS behavior as proof of sustained application slowness unless the evidence directly supports that interpretation.


## Automatic PCAP escalation

When a relevant MCP event exposes `pcap_url`/`pcap_urls`, automatically invoke `orchestrator/pcap-analysis.md` after attribution. Do not wait for a follow-up prompt. If retrieval is blocked, record the retrieval limitation and continue the playbook. If the operator later attaches the capture, analyze it as the same incident evidence.
