---
name: dhcp-failure
description: Diagnose wireless client DHCP/IP assignment failures after successful association and authentication.
---

# DHCP Failure Playbook

## Trigger
Use when the client is associated and authenticated but does not receive a valid IP configuration.

## Required Evidence
- Client MAC
- AP/site/SSID
- Authentication success
- Client IP state
- Expected VLAN/subnet from knowledge
- DHCP events/SLEs where available
- Gateway information
- Scope of affected clients
- Relevant VLAN/DHCP/relay changes

## Procedure
1. Confirm association.
2. Confirm authentication.
3. Determine expected client VLAN/subnet.
4. Check whether an IP was assigned.
5. Check DHCP success/failure evidence.
6. Check whether other clients on the same VLAN/AP are affected.
7. Check relevant VLAN/relay/gateway information.
8. Check recent changes.
9. If IP assignment succeeds, stop DHCP playbook and continue to DNS/gateway testing.

## Packet-capture escalation

If the relevant DHCP/IPv4 event exposes `pcap_urls`, use `orchestrator/pcap-analysis.md` to correlate DHCP Discover/Offer/Request/Ack, retransmissions and timing with the exact incident. A missing DHCP frame is only meaningful when the capture coverage makes that absence observable.

## Scope Logic
One client → client-specific DHCP/client behavior.
Multiple clients on same VLAN → DHCP scope/relay/VLAN/gateway dependency.
Multiple APs/site-wide → shared DHCP/VLAN/infrastructure dependency.

## Output
DHCP summary, scope, evidence, failure point, likely RCA, recommended action, confidence, data gaps.

## Evidence Rules
Do not call DHCP the root cause merely because the client has no IP. Confirm that DHCP is the first failed stage.


## Automatic PCAP escalation

When a relevant MCP event exposes `pcap_url`/`pcap_urls`, automatically invoke `orchestrator/pcap-analysis.md` after attribution. Do not wait for a follow-up prompt. If retrieval is blocked, record the retrieval limitation and continue the playbook. If the operator later attaches the capture, analyze it as the same incident evidence.
