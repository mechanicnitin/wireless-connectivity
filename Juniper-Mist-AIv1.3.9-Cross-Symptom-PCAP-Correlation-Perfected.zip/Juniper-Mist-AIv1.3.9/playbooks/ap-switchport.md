---
name: ap-switchport
description: Diagnose AP wired connectivity through its connected switchport, including link, PoE, LLDP, VLAN, MAC learning and interface health.
---

# AP Switchport Playbook

## Trigger
Use when an AP is down/unreachable, multiple clients on an AP fail, or evidence points to the AP's wired path.

## Required Evidence
- AP identity/MAC
- Connected switch/interface
- Port operational state
- PoE
- LLDP
- Interface errors/flaps
- AP MAC learning
- Relevant VLAN/configuration
- Recent switchport changes

## Procedure
1. Identify expected AP-to-switch path from knowledge.
2. Verify observed switch/interface.
3. Check admin and operational link state.
4. Check speed/duplex and link flaps.
5. Check PoE state, delivered power and faults.
6. Check LLDP neighbor against expected AP/topology.
7. Check AP MAC learning on expected interface/VLAN.
8. Check relevant client MAC learning where applicable.
9. Check interface errors, CRC, drops and discards.
10. Validate VLAN/access/trunk configuration against site design.
11. Correlate recent changes.
12. Determine whether the issue is local to the port or broader.

## Decision Logic
Port down → investigate link/configuration.
PoE fault → investigate power/cabling/switch capability.
Unexpected LLDP → investigate topology/cabling.
AP MAC not learned → investigate AP link/VLAN/port path.
Errors/flaps → investigate physical/interface health.
Expected port healthy → return to AP/RF/client investigation.

## Output
Path, evidence, failure point, likely RCA, action, confidence and data gaps.

Never invent switch CLI state if MCP does not provide it.
