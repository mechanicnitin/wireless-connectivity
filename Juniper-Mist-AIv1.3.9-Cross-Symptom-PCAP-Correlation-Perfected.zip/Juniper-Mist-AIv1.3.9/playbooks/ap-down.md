---
name: ap-down
description: Diagnose an AP that is offline or unreachable from Juniper Mist.
---

# AP Down Playbook

## Trigger
Use when Mist indicates an AP is offline, unreachable, or has stopped reporting.

## Required Evidence
- AP/site
- Last-seen time
- AP health/management state
- Reboots/disconnects
- Alarms/alerts
- Connected switch/interface
- PoE
- LLDP
- AP MAC learning
- Interface state/errors
- Recent changes

## Procedure
1. Confirm AP is actually offline.
2. Establish last known healthy time.
3. Check AP reboots/disconnect events.
4. Trace AP to switch/interface.
5. Run AP switchport checks.
6. Check PoE.
7. Check LLDP and MAC learning.
8. Check upstream/site connectivity if required.
9. Check whether other APs on the same switch/site are affected.
10. Correlate recent changes.

## Scope
One AP → AP/port/cabling/PoE.
Several APs on one switch → switch/uplink/power dependency.
Many APs site-wide → site infrastructure/WAN/shared dependency.

## Output
AP state, timeline, evidence, confirmed failure point, likely RCA, action, confidence and data gaps.
