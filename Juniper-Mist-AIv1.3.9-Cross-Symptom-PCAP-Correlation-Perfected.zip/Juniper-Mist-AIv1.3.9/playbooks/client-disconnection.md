---
name: client-disconnection
description: Diagnose repeated wireless client disconnects after association, including RF, AP, authentication and network-path evidence.
---

# Client Disconnection Playbook

## Trigger
Use when a client associates successfully but repeatedly disconnects or experiences unstable connectivity.

## Required Evidence
- Client/AP/SSID
- Connection/disconnection timeline
- Disconnect reason
- Association/authentication state
- RSSI/SNR
- Retries/channel utilization
- Roaming events
- AP health
- Relevant SLEs/alarms
- AP wired-path evidence when multiple clients are affected
- Recent changes

## Procedure
1. Confirm the client can associate.
2. Build an event timeline.
3. Identify whether disconnect occurs during association, authentication or after full connectivity.
4. Check disconnect reason.
5. Analyze RF indicators.
6. Check roaming behavior.
7. Compare with healthy clients on same AP.
8. If multiple clients are affected, check AP and wired path.
9. Check authentication/DHCP if disconnect is actually a later-stage failure.
10. Correlate recent changes.

## Packet-capture escalation

If a relevant disconnect/roam/authentication event exposes `pcap_urls`, correlate the capture with the exact client/AP/timestamp and use `orchestrator/pcap-analysis.md` to distinguish RF/roaming/authentication packet behavior from downstream symptoms.

## Classification
- RF/client-specific
- AP-specific
- AP wired-path
- Authentication
- DHCP/network
- Roaming
- Recent-change related
- Unknown

Do not assume every disconnect is RF-related.


## Automatic PCAP escalation

When a relevant MCP event exposes `pcap_url`/`pcap_urls`, automatically invoke `orchestrator/pcap-analysis.md` after attribution. Do not wait for a follow-up prompt. If retrieval is blocked, record the retrieval limitation and continue the playbook. If the operator later attaches the capture, analyze it as the same incident evidence.
