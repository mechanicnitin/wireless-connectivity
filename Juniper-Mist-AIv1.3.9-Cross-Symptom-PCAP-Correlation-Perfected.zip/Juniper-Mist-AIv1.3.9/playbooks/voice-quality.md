---
name: voice-quality
description: Focused playbook for poor Wi-Fi voice/meeting quality, including latency, jitter, packet loss, roaming interruption and RF/capacity contributors.
---

# Voice Quality Playbook

## Trigger
Use when the user reports poor voice quality, choppy audio, one-way audio, call drops, high jitter, voice latency, or degraded wireless meeting quality after or during connectivity.

## Do not assume

Poor voice quality is not automatically RF, WAN, DNS, roaming or application failure. Determine whether the impairment is actually wireless, network-path, roaming-related, application/meeting-related, or a combination.

## Required evidence
- incident timestamps and call/meeting periods where available
- client/AP/WLAN
- RSSI/SNR and RF trends
- retries/retransmissions/channel utilization where available
- roaming/disassociation timeline
- packet loss/latency/jitter evidence where exposed
- gateway/network-path indicators
- application/meeting/voice SLEs or packet evidence where available
- affected vs healthy clients/calls
- recent changes

## Procedure
1. Establish the exact impairment window.
2. Confirm whether the client remained associated/authenticated.
3. Correlate roaming/disconnects with the impairment.
4. Correlate RF, retries and airtime/load with the same timestamps.
5. Check IPv4/gateway/network path when packet loss or latency suggests a post-RF dependency.
6. Use application/meeting telemetry when available.
7. If `pcap_urls` are exposed for the relevant incident, use `orchestrator/pcap-analysis.md` to corroborate packet-level loss/timing or voice behavior.
8. Compare affected and healthy clients.

## Decision logic

- RF degradation aligned with packet loss/retries → RF is a supported contributor.
- Roam/disconnect aligned with the audio impairment → roaming/connectivity interruption is a supported contributor.
- Wireless path is healthy but gateway/WAN/application evidence degrades → investigate downstream dependency.
- Application-specific evidence exists without corresponding wireless degradation → do not blame Wi-Fi.

## Output
Separate confirmed impairment, supported contributors, ruled-out domains, remaining hypotheses, confidence, data gaps and minimum next test.


## Automatic PCAP escalation

When a relevant MCP event exposes `pcap_url`/`pcap_urls`, automatically invoke `orchestrator/pcap-analysis.md` after attribution. Do not wait for a follow-up prompt. If retrieval is blocked, record the retrieval limitation and continue the playbook. If the operator later attaches the capture, analyze it as the same incident evidence.
