---
name: association-failure
description: Playbook for diagnosing a wireless client that cannot associate to an AP or repeatedly fails association.
---

# Association Failure Playbook

## 1. Trigger

Use this playbook when the wireless troubleshooting skill identifies one or more of these conditions:

- Client cannot associate to an AP.
- Association attempts fail.
- Client repeatedly associates and disconnects before authentication completes.
- Mist telemetry identifies an association-related failure.

Do not use this playbook when association is confirmed successful and the failure is clearly at authentication, DHCP, DNS, or a later stage.

---

## 2. Objective

Determine:

1. Whether the failure is actually at the association stage.
2. Whether the issue is client-specific, AP-specific, area-wide, or site-wide.
3. Whether RF/client conditions, AP health, configuration, or the AP's wired path provide evidence for the failure.
4. The first confirmed failure point.
5. The next appropriate troubleshooting action.

---

## 3. Required Evidence

Collect from Juniper Mist MCP and other available trusted data:

### Client
- Client identifier/MAC
- SSID
- AP
- First/last seen
- Association state
- Association attempts/events
- Failure/disconnect reason
- Event timestamps

### AP
- AP online/offline state
- AP health
- Recent reboots/disconnects
- Relevant SLEs
- Relevant alarms/alerts
- Recent changes

### RF
Where available:
- RSSI
- SNR
- Channel
- Channel utilization
- Retry/retransmission indicators
- PHY/rate information
- Roaming/neighbor context

### Scope
Determine whether:
- One client is affected.
- Multiple clients on the same AP are affected.
- Multiple APs in the same area are affected.
- The issue is broader across the site.

### Wired AP path
If the evidence suggests AP-side or AP-wide impact, check:
- Connected switch
- Switchport
- Port operational state
- PoE
- LLDP
- AP MAC learning
- Interface errors/flaps
- Expected VLAN/configuration

Do not query or report information that the available MCP does not expose.

---

## Packet-capture evidence

If an association-failure event exposes `pcap_urls` or an equivalent capture reference, invoke `orchestrator/pcap-analysis.md` after validating client/AP/timestamp attribution. Inspect association request/response, status/reason codes, RSN/PMF/FT context and retransmissions where visible. Do not infer AP-side or RADIUS-side behavior that the capture does not expose.

## 4. Procedure

### Step 1 — Confirm the failure stage

Confirm that association is actually failing.

Check the client event timeline and distinguish:

```text
Association failure
        ≠
Authentication failure
        ≠
DHCP failure
        ≠
DNS failure
```

If association succeeds, stop this playbook and hand the investigation back to the parent wireless skill for the next stage.

---

### Step 2 — Establish the scope

Classify the incident:

```text
One client
    → Client/RF/AP investigation

Multiple clients on one AP
    → AP/RF/wired-uplink investigation

Multiple APs in one area
    → Shared infrastructure/RF investigation

Many clients across site
    → Site/shared-service investigation
```

Scope is evidence for prioritization, not proof of root cause.

---

### Step 3 — Check client-specific evidence

Review:

- Association attempts
- Failure reason
- Disconnect/reassociation pattern
- RF metrics
- Roaming behavior
- Whether the same client can associate with another AP, if that information is available

If the evidence is isolated to one client and other clients are healthy, prioritize client-specific or RF evidence.

---

### Step 4 — Check AP health

Review:

- AP availability
- AP management connectivity
- Reboots
- Relevant SLEs
- Alarms/alerts
- Recent changes

If multiple clients on the AP fail association, increase priority of AP/RF/wired-path checks.

---

### Step 5 — Check RF evidence

Correlate multiple RF indicators with the association failure.

Look for:

- Poor RSSI/SNR
- High channel utilization
- Excessive retries
- Abnormal PHY/rate behavior
- Roaming instability
- RF-related SLE degradation

Do not declare RF as the root cause from a single metric.

---

### Step 6 — Check AP wired path when justified

If the AP itself appears unhealthy or multiple clients are affected, investigate the AP's wired connection.

Check:

1. Connected switch/interface
2. Port operational state
3. PoE
4. LLDP
5. AP MAC learning
6. Interface errors/flaps
7. VLAN/configuration consistency

If these checks cannot be performed because MCP does not expose the required information, explicitly report the data gap.

---

### Step 7 — Check recent changes

Correlate incident timestamps with:

- WLAN/SSID changes
- AP configuration changes
- RF configuration changes
- Switchport changes
- VLAN changes
- Authentication/security changes
- Firmware/software changes

A temporal correlation is a candidate cause, not proof of RCA.

---

## 5. Decision Logic

Use this decision tree:

```text
Association failure confirmed?
│
├── NO
│   └── Return to parent wireless troubleshooting skill
│
└── YES
    │
    ├── One client?
    │     ├── Client/RF evidence
    │     └── Compare with healthy clients/APs
    │
    ├── Multiple clients on one AP?
    │     ├── AP health
    │     ├── RF
    │     └── AP wired path
    │
    ├── Multiple APs affected?
    │     ├── Shared RF/environment
    │     ├── Switching/uplinks
    │     └── Common configuration
    │
    └── Site-wide?
          ├── Site infrastructure
          ├── Common configuration
          └── Shared dependencies
```

---

## 6. Root-Cause Classification

Use one of these classifications when supported by evidence:

- Client-specific
- RF-related
- AP-specific
- AP wired-path related
- Switchport/PoE related
- VLAN/configuration related
- Site/shared-infrastructure related
- Recent-change related
- Unknown / insufficient evidence

Do not force a root cause if the evidence is inconclusive.

---

## 8. Output Format

Return:

### Association Failure Summary
One or two sentences.

### Scope
- Client(s)
- AP(s)
- Site
- SSID
- Scope classification

### Evidence
List the important observations with timestamps where available.

### Investigation Path
Show the major checks performed.

### Confirmed Failure Point
State the first confirmed failed stage.

### Root Cause
State the most likely cause only when supported by evidence.

### Recommended Action
Give the next operational action.

### Confidence
- High
- Medium
- Low

Explain why.

### Data Gaps
List required checks that could not be performed.

### Next Step
If association remains unresolved, state which skill/playbook should be invoked next.

---

## 8. Safety / Evidence Rules

- Never invent MCP results.
- Never claim a port, AP, PoE, LLDP, MAC, or RF condition unless evidence supports it.
- Separate observed telemetry from documented topology.
- Use site knowledge to determine expected behavior, not current state.
- Use live MCP data to determine current state.
- Treat inferred root causes as hypotheses until supported by evidence.
- If evidence is insufficient, say so explicitly.

## Entry-versus-roam differential

When association failures occur around roaming, automatically separate source-AP departure, roam execution, destination association, authentication, and post-entry behavior. Compare successful FT/11r entries with failed/full-EAP entries and peer AP behavior. A successful roam to a weaker-RSSI destination does not establish why the client left the source AP.

When an AP swap/replacement is reported, load `orchestrator/controlled-intervention-analysis.md` and compare AP identity against physical location before classifying the fault as RF/location or AP-specific.



## Automatic PCAP escalation

When a relevant MCP event exposes `pcap_url`/`pcap_urls`, automatically invoke `orchestrator/pcap-analysis.md` after attribution. Do not wait for a follow-up prompt. If retrieval is blocked, record the retrieval limitation and continue the playbook. If the operator later attaches the capture, analyze it as the same incident evidence.
