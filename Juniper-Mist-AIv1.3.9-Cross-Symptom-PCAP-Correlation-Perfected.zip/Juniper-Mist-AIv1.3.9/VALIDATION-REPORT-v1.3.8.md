# Juniper Mist AI v1.3.9 — Cross-Symptom / PCAP Correlation Validation Report

## v1.3.9 delta validation

This revision preserves v1.3.8 and adds only targeted automatic-PCAP, controlled-intervention, AP identity/location, and regression protections.

### Regression cases

**Case A — replacement AP false-positive prevention**
- A replacement AP generates disconnect/restart/config-change events during the controlled swap.
- Expected: those events are retained as test context and do not increase replacement-AP fault confidence.

**Case B — AP identity follows the problem**
- Replacement AP works in the old location; suspect AP fails after relocation.
- Expected: strong AP-identity evidence, location hypothesis weakened, internal mechanism still unconfirmed.

**Case C — site-wide background plus AP-specific differential**
- Same auth failure exists on multiple APs, but the controlled swap produces a repeatable AP-specific differential.
- Expected: report both layers rather than forcing either a purely site-wide or purely AP-specific RCA.

**Case D — PCAP URL present**
- Relevant MCP event exposes `pcap_url`.
- Expected: automatic retrieval attempt before RCA, with explicit retrieval/parse state. No second user prompt required.

**Case E — PCAP blocked**
- Runtime returns host allowlist/session/HTTP failure.
- Expected: continue MCP investigation, report packet evidence unavailable, never classify the block as network/AP evidence.

**Case F — manually attached PCAP**
- Operator later attaches the capture.
- Expected: validate/parse and correlate to the original event without bypassing attribution gates.

## Result

**PASS — v1.3.6 retained as the baseline and selectively extended for cross-symptom automatic correlation, packet-capture corroboration, and voice-quality investigation. Unrelated working modules and normal MCP behavior were preserved.**

## What was preserved

- Normal MCP queries remain normal MCP queries.
- Troubleshooting activates only for diagnostic intent.
- Juniper Mist MCP/live telemetry remains the primary operational evidence source.
- Broad-first wireless investigation remains mandatory before focused playbooks.
- IPv6/DHCPv6 remains out of scope for this IPv4-only environment unless explicitly requested.
- Existing knowledge, skills and focused playbooks remain intact except for targeted consistency hardening.

## Historical changes retained from earlier baseline

1. Added `orchestrator/investigation-context.md` to keep entity, timezone, incident episode and causal window consistent across all queries.
2. Added `orchestrator/telemetry-collection-contract.md` to capture the master-prompt evidence requirements without embedding the full prompt into every file.
3. Added `orchestrator/second-opinion.md` for optional independent Marvis VNA comparison; it is not a mandatory dependency.
4. Hardened the investigation engine so the true dependency chain is separated from cross-cutting RF/AP/wired/SLE/scope evidence.
5. Hardened first-failure reasoning to distinguish first abnormal observation, first observed failure, earliest confirmed broken dependency, and downstream symptoms.
6. Strengthened affected-vs-healthy control comparison as negative evidence.
7. Strengthened performance troubleshooting so DHCP/RADIUS/reconnect latency, weak RF, or DNS observations are not automatically treated as proof of sustained application slowness.
8. Added investigation-context and failure-domain correlation visibility to the response contract.
9. Added `orchestrator/investigation-gap-closure.md` and made the evidence sufficiency/closure gate mandatory.
10. Kept normal-query routing unchanged.

## Historical validation checks retained

- Evidence sufficiency / closure gate: PASS
- Contradiction and event-attribution handling: PASS
- AP uptime versus manual/admin reboot distinction: PASS
- Admin/audit/change correlation when reboot is relevant: PASS
- Site-local timestamp presentation: PASS
- AP-name-over-BSSID presentation when mapping is available: PASS
- RADIUS server/timestamp/other-client correlation: PASS
- Affected + healthy control-group requirement: PASS
- RCA not-yet-confirmed evidence boundary: PASS

## Validation checks

- Normal query protection: PASS
- Hybrid query behavior: PASS
- Broad-first troubleshooting: PASS
- Shared investigation context: PASS
- Stable causal window across modules: PASS
- Telemetry collection contract: PASS
- Chronological correlation: PASS
- Earliest confirmed dependency: PASS
- Association/authentication/authorization separation: PASS
- RF evidence discipline: PASS
- AP/client scope correlation: PASS
- Healthy control-group comparison: PASS
- IPv4/DHCP/ARP/gateway/DNS path: PASS
- IPv6/DHCPv6 exclusion: PASS
- Recent-change correlation: PASS
- RCA evidence-for/evidence-against discipline: PASS
- Minimum-next-test logic: PASS
- Optional second-opinion isolation: PASS
- Focused playbook handoff: PASS

## Operational limitation

The package cannot force the MCP to expose telemetry it does not provide. Missing telemetry must be reported as a data gap. The package does not implement a Marvis VNA API call.

## Recommended test order

1. Normal: list APs at a site.
2. Normal: Mist Edge subscription expiry/status.
3. Normal: configured admin-user count.
4. Hybrid: list APs and identify unhealthy ones.
5. Client: why is client `<MAC>` slow?
6. Client: investigate client `<MAC>` comprehensively.
7. Site: investigate poor wireless performance at `<SITE>`.
8. Cross-client/shared-service incident.
9. Compare the same incident context with Marvis VNA and inspect agreement/disagreement.


## v1.3.6 targeted validation

- v1.3.5 baseline preserved: PASS
- Automatic named-client deep timeline: PASS
- Same-client/same-AP and peer-AP differential: PASS
- Full-EAP vs 802.11r/FT differential: PASS
- Minimum-differentiating-factor guardrail: PASS
- Timestamp/AP/BSSID event-attribution guardrail: PASS
- Roam decision vs roam execution separation: PASS
- AP replacement/relocation control analysis: PASS
- RADIUS AP→server and client→server population visibility: PASS
- RADIUS blank-IP attribution guardrail: PASS
- Firmware/model/hardware/uptime/reboot parity discipline: PASS
- AP-specific scope versus internal-mechanism evidence boundary: PASS

## Change scope

Only the orchestrator correlation/investigation logic, relevant authentication/association playbooks, and validation/README metadata were extended. No unrelated knowledge, memory, response, RF/DHCP/DNS modules, or normal-query routing behavior was redesigned.


## v1.3.8 targeted validation

- v1.3.6 baseline preserved: PASS
- Symptom normalization across slow/connect/roam/disconnect/voice/high-ping/association/authentication/IP symptoms: PASS
- Broad-first investigation remains mandatory: PASS
- Normal MCP query protection remains unchanged: PASS
- PCAP reference attribution to client/AP/event/timestamp: PASS
- Safe PCAP retrieval guardrail (no guessed URLs): PASS
- Packet-level evidence separated from MCP/RADIUS-side evidence: PASS
- PCAP timestamp correlation and negative-evidence limitations: PASS
- PCAP confidence impact without automatic mechanism attribution: PASS
- Voice-quality focused playbook: PASS
- Association/authentication/performance/disconnection PCAP escalation: PASS
- IPv4-only policy preserved: PASS
- AP replacement/relocation and event-attribution safeguards preserved: PASS
- RCA evidence boundary preserved: PASS

## v1.3.8 change scope

Changes are confined to the orchestrator investigation/correlation layer, the relevant association/authentication/performance/disconnection playbooks, a new shared PCAP-analysis module, a focused voice-quality playbook, and README/validation metadata. No unrelated knowledge, memory, normal-query routing, DHCP/DNS core logic or existing working architecture was redesigned.


## Additional v1.3.8 validation — controlled replacement and PCAP access

### AP replacement test case

Validation scenario: a suspect AP was removed from its original location and a replacement AP was installed there; the suspect AP was then placed in a different location for comparison.

Expected behavior:
- replacement AP reboot/disconnect/reconnect events caused by the installation are classified as test-generated/administrative context, not independent replacement-AP faults;
- the original location and moved suspect AP are evaluated as a controlled identity-versus-location comparison;
- if the symptom follows the suspect AP while the replacement works in the original location, AP-specific scope confidence increases;
- the mechanism remains unconfirmed unless direct telemetry establishes it.

### PCAP access validation

Expected behavior:
- `pcap_url`/`pcap_urls` returned by MCP is treated as a sensitive evidence reference;
- a URL is not considered packet evidence until the authorized runtime actually retrieves and parses the capture;
- portal/session-protected or signed URLs that cannot be retrieved are recorded as `REFERENCE_RETURNED_NOT_RETRIEVED`;
- the model must never expose or reproduce bearer tokens in the final RCA;
- packet evidence must be tied to the source client/AP/event/timestamp before changing RCA confidence.

### Regression objective

The package must continue to support automatic broad-first troubleshooting for slow Wi-Fi, inability to connect, roaming/walking drops, repeated disconnects, voice-quality degradation, high ping/latency, association failure, authentication failure and missing IPv4 address, while preserving normal MCP lookup behavior.


## v1.3.8 direct PCAP retrieval validation

- Exact MCP `pcap_url` retrieval path documented: PASS
- Generic `application/octet-stream` accepted: PASS
- PCAP/PCAPNG magic-byte validation: PASS
- Bounded retrieval and temporary-file handling: PASS
- Signed URL/JWT redaction rule: PASS
- Explicit distinction between retrieval and parsing: PASS
- Environment egress/allowlist failures cannot become RCA evidence: PASS
- Cross-symptom applicability preserved: PASS
