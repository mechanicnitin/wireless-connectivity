---
name: event-correlation
version: 1.3.9
description: Chronological correlation of client and infrastructure events.
---

# Event Correlation

## Rule

Timestamp correlation is mandatory for causal claims.

## Build the timeline

Merge available events from:
- client
- AP
- radio
- association/reassociation
- authentication/authorization/RADIUS
- deauthentication/disassociation
- roaming/802.11r/FT/PMF/SA Query
- DHCP/IPv4
- ARP/gateway
- DNS
- AP wired path
- SLE/entity/action events
- configuration/firmware/network changes

Sort chronologically and mark the first confirmed failure.

## Before/after context

For every significant failure, inspect the immediately preceding and following events. A failure reason without temporal context is insufficient for RCA.

## Event semantics

Do not collapse distinct stages:
- association ≠ authentication
- authentication ≠ authorization
- authorization ≠ DHCP
- DHCP ≠ DNS
- deauthentication ≠ root cause
- SLE degradation ≠ proof of causality

## Correlation confidence

- Direct temporal + dependency evidence → strong
- Temporal overlap + shared scope → moderate
- Same day / same site only → weak

Only strong/moderate evidence should influence RCA ranking.


## Contradiction and attribution checks

Before using an event as causal evidence, verify:

- timestamp and timezone
- client identity
- AP identity
- WLAN/SSID where available
- whether AP identity is a resolved AP name, AP ID, or BSSID
- whether the record is historical or current-state data
- whether a state transition occurred between apparently conflicting records

If an event shows a BSSID and the historical AP-name mapping is available, use the AP name in the human-facing timeline and retain the BSSID as supporting identity data. Never infer a historical AP name from the client's current AP.

If two events appear contradictory, do not select one without checking for timestamp, timezone, entity, state-transition, or source-type differences. If the contradiction remains unresolved, mark it as an evidence gap.

## Reboot / uptime attribution

A short AP uptime or a recent reboot is not itself proof of AP failure. When an AP reboot overlaps the incident, check available AP event data and administrator/audit/change logs for evidence of a manual reboot, maintenance action, configuration action, power event, software event, or fault. Only attribute the reboot as causal when telemetry supports that conclusion.

## Intervention and roam attribution guardrails

When a reboot, AP relocation/swap, replacement, or other controlled intervention occurred, correlate the intervention timestamp with the event timeline and use `orchestrator/controlled-intervention-analysis.md`. Do not infer causality from the intervention alone.

For a roam sequence, do not treat `AP03 strong RSSI → authentication success/DHCP → immediate roam to AP04` as proof that AP03 caused the roam. Determine whether the roam was client-driven, AP/RRM/steering-related, 802.11k/v/r-related, or a consequence of a post-association condition. Correlate roam trigger/reason, neighbor/steering evidence, APs before/after, authentication/authorization, and post-roam connectivity.

Where multiple AP identities and physical locations changed during a test, maintain separate identity and location dimensions so historical BSSID/AP attribution is not confused with the physical RF environment.

## Timeline attribution guardrail

Every event used in a causal chain must retain these dimensions together:

**timestamp + site-local time + client + AP + previous AP + next AP + event type + state/outcome**.

Never attribute an event to AP03 merely because it appears between AP03 events. Verify the event's own AP/BSSID attribution. If an event is attributed to AP04, keep it as AP04 evidence even when the surrounding sequence concerns AP03.

For each material transition, build:

`previous state → event → resulting state`

Examples:
- AP03 authenticated → client deauthenticates AP03 → AP03→AP04 FT reassociation succeeds
- AP04 session ends → new AP03 association fails → AP03 authentication fails → AP04 fallback succeeds

These are different episodes unless the telemetry establishes a dependency between them.

## Roam-decision versus roam-execution

A successful `CLIENT_AUTH_REASSOCIATION_11R` or equivalent event proves the reassociation executed successfully. It does **not** by itself prove why the client initiated the roam.

For every material roam, separately record:
- source AP and destination AP
- departure RSSI/SNR
- destination RSSI/SNR
- explicit roam trigger/reason when exposed
- 802.11k/v/r or steering evidence when exposed
- preceding authentication/association state
- post-roam authentication, DHCP/IP, and connectivity outcome

If the trigger is not exposed, report **roam trigger not established** rather than inferring it from the destination RSSI.

## Hard event-attribution guardrail

Timeline proximity is not AP attribution. Before correlating an event to a suspect AP, verify the event's own AP/BSSID field against the client identity and timestamp. Use the immediately preceding and following events to establish the transition context. A sequence such as `AP03 → AP04 → auth failure` must not cause an AP04 event to be labeled AP03 merely because AP03 is the investigation target.

For each causal chain, retain: `timestamp → client → event type → event AP/BSSID → previous AP → next AP → outcome`. If any required identity is unavailable, mark the chain as partially attributed and lower confidence.

## Roam causality separation

Represent roaming as four separate questions:

1. **Roam decision:** why did the client leave the source AP?
2. **Roam execution:** did the reassociation/FT exchange succeed?
3. **Destination entry:** did authentication/association succeed at the destination?
4. **Post-entry stability:** did the client remain healthy afterward?

A successful AP03→AP04 FT reassociation, even when the destination RSSI is weaker, proves only that the roam executed. It does not prove why the client selected AP04. Candidate triggers such as client policy, RF, steering, load balancing, band preference, 11r behavior, or AP state remain hypotheses until telemetry discriminates them.



## Test-window contamination guardrail

Before assigning causal weight to AP restart, disconnect, reconnect, configuration-change, or power events, determine whether the event was generated by a known troubleshooting test or maintenance action. If yes:

- preserve the event in the timeline;
- tag it as test-generated/administrative context;
- correlate it to the test start/end;
- do not count it as an independent AP fault;
- only use it as causal evidence if an independent client-impacting failure remains after the test context is removed.

This prevents a deliberate AP replacement from producing a false diagnosis against the replacement AP.


## Controlled-test event quarantine

For every AP event near an identified replacement, relocation, reboot or maintenance action, create an `event_role` before RCA scoring:

- `independent_incident_event`
- `test_generated_event`
- `administrative_context`
- `ambiguous`

Only `independent_incident_event` may increase AP-fault confidence. `test_generated_event` and `administrative_context` may explain a failure or change state, but cannot by themselves establish AP fault.

If a client failure occurs at the same time as an AP restart, do not assume the restart caused the failure. First determine whether the restart was the intended intervention. If yes, quarantine it from fault scoring and compare the client outcome before/after the intervention.
