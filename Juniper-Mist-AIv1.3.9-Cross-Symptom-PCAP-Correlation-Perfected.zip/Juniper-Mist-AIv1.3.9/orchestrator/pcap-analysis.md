---
name: pcap-analysis
version: 1.3.9
description: Controlled packet-capture retrieval and correlation layer for Juniper Mist wireless investigations when MCP exposes PCAP references such as pcap_urls.
---

# Packet Capture Analysis

## Purpose

Use PCAP as an additional evidence layer when Juniper Mist MCP operational events expose a packet-capture reference. PCAP is intended to strengthen or falsify an existing hypothesis, not replace the MCP-first investigation.

## Activation

Activate when:
- a relevant MCP event contains `pcap_urls` or an equivalent capture reference; and
- the capture can be retrieved through an authorized/runtime-supported mechanism.

If either condition is false, record a data gap and continue without PCAP.

## Attribution gate

Before using a capture, bind it to:
- source MCP event
- exact event timestamp
- client MAC/identity
- AP/BSSID
- WLAN/SSID where exposed
- incident episode

Do not assume that a PCAP returned near an event belongs to the same AP/client unless the returned metadata and packet contents support that attribution.

## Safe retrieval

For direct retrieval, follow `orchestrator/pcap-download.md`. A Mist capture download may legitimately return `Content-Type: application/octet-stream`; content type alone must never cause the downloader to reject the capture. Validate the returned bytes using PCAP/PCAPNG magic signatures before parsing.

- Use the exact reference returned by MCP.
- Never invent, normalize, guess, or substitute a URL.
- Do not retrieve unrelated captures.
- Do not expose credentials, tokens or signed URL contents in the final RCA.
- If the runtime cannot fetch the reference, state that limitation; do not claim PCAP analysis was performed.
- A capture URL may be a signed/temporary portal-protected reference and may require the authorized Mist session/runtime that issued it. Do not assume a URL is anonymously retrievable merely because it is syntactically complete.
- Never ask the model to paste or expose bearer tokens from a capture URL into the RCA.

## Retrieval-result states

Record one of:

- `RETRIEVED_AND_PARSED` — capture bytes were obtained and packet facts were extracted.
- `REFERENCE_RETURNED_NOT_RETRIEVED` — MCP supplied a reference but the runtime could not retrieve it.
- `RETRIEVED_NOT_PARSEABLE` — capture was obtained but useful packet decoding was unavailable.
- `ATTRIBUTION_FAILED` — capture could not be reliably tied to the client/AP/event.

Only `RETRIEVED_AND_PARSED` may be described as packet-level analysis.

## Packet evidence extraction

Extract structured facts appropriate to the incident, for example:

### Association / authentication
- Association Request/Response
- status/reason codes
- RSN/security information
- PMF negotiation where visible
- EAPOL start/identity/request/response
- EAP method and success/failure
- retransmissions and response timing

### Roaming / 802.11r
- FT/802.11r action frames or reassociation
- mobility-domain/FT information where visible
- PMKID/FT status where visible
- failed FT followed by full-EAP fallback
- successful FT without unnecessary full-EAP fallback

### IPv4 / connectivity
- DHCP discover/offer/request/ack
- DHCP retransmission/timeout patterns where visible
- ARP request/reply
- ICMP echo timing/loss when actually present

### Performance / voice
- packet loss/retransmissions
- timing/RTT where measurable
- RTP/voice packet behavior only if the capture contains usable voice traffic

## Correlation rules

Correlate packet timestamps with MCP events using the same incident window and timezone conversion rules. Prefer exact or near-exact timestamp alignment over narrative similarity.

Use three layers:

```text
MCP event
   +
PCAP packet facts
   +
Peer/healthy/control evidence
   ↓
Hypothesis confidence
```

Examples:
- MCP says authentication failed + PCAP shows EAPOL exchange stopping after a client response + peer AP completes the same exchange → stronger AP-path hypothesis.
- MCP says FT failure + PCAP shows failed FT/PMKID exchange followed by full-EAP + full-EAP succeeds on a peer AP → FT-specific hypothesis becomes more plausible, but do not claim the internal AP key-management mechanism without direct evidence.
- MCP says high latency + PCAP contains ICMP timing/loss aligned with the symptom → stronger packet-path evidence; still determine whether the latency is RF, gateway, wired/WAN or application-specific.

## Negative evidence

Absence of a packet in a capture is only meaningful when the capture is known to cover the relevant interface/time and the expected packet should be visible. A missing frame can indicate capture limitations rather than a network failure.

## Confidence rules

PCAP may:
- strengthen a confirmed observation
- weaken a hypothesis
- identify the earliest visible packet-level failure
- expose a protocol fallback or retry pattern

PCAP alone should not be used to claim an internal AP, RADIUS, client-supplicant or application mechanism unless the capture directly exposes that mechanism.

## Output

Include:
1. capture reference/event used
2. attribution validation
3. packet-level observations
4. MCP correlation
5. control/peer comparison where available
6. what PCAP strengthens
7. what PCAP cannot prove
8. confidence impact
9. remaining data gaps


## Capture-selection contract

Do not choose a PCAP merely because it is the first URL returned. Rank candidate captures by: exact failure event match, exact client/AP match, proximity to the first confirmed failure, protocol relevance, and availability of a peer/control capture.

For each selected capture, preserve a compact evidence record:

```text
source_event_timestamp
source_event_type
client
ap/bssid
previous_ap
next_ap
incident_episode
retrieval_state
parse_state
packet_facts
```

## Cross-symptom packet mapping

Use the same automatic PCAP path for:
- slow Wi-Fi / high ping: ICMP/transport timing, retransmission/loss and only the application traffic actually present;
- connect/association failure: association, status/reason, RSN/PMF/FT and retransmissions;
- authentication failure: EAPOL/802.1X sequence, response timing and FT fallback;
- roaming/walking drops: source/destination AP, FT/PMF, reassociation and post-roam traffic;
- repeated disconnects: deauth/disassoc plus surrounding RF/authentication evidence;
- voice quality: RTP/UDP timing, loss/jitter where voice packets are present;
- DHCP/IP failure: DHCP discover/offer/request/ack and ARP when present.

PCAP must strengthen or weaken an existing hypothesis; it must not manufacture a mechanism outside the visible packet evidence.
