---
name: pcap-download
version: 1.3.9
description: Direct retrieval and validation of Juniper Mist MCP-provided signed PCAP URLs.
---

# Direct PCAP Retrieval

## Purpose

When MCP returns `pcap_url` or `pcap_urls`, the orchestrator SHOULD attempt direct retrieval when the runtime permits outbound HTTPS access to the exact returned host. This is an evidence-acquisition step; it does not itself prove the capture is relevant or causal.

Juniper Mist has regional API hosts, including APAC `api.ac5.mist.com`; use the exact host returned by MCP rather than substituting a different regional host. Mist's API documentation identifies `api.ac5.mist.com` as the APAC 01 API host. urlJuniper Mist API environmentshttps://www.juniper.net/documentation/us/en/software/mist/api/http/getting-started/how-to-get-started

## Retrieval contract

### Automatic-attempt rule

When a relevant MCP event exposes `pcap_url` or `pcap_urls`, PCAP retrieval is an **automatic investigation step**, not an optional follow-up question. The orchestrator must attempt the highest-value capture(s) immediately after attribution, without waiting for the operator to say "pull the PCAP". A failed retrieval must never stop the investigation.

Select captures in this order:
1. exact event matching the earliest confirmed failure;
2. same client/AP event immediately before or after the failure;
3. peer-AP/healthy-control capture for the same protocol;
4. a second independent affected-client capture when needed for reproducibility.

Bound the default automatic sample (for example 1–3 captures) to avoid downloading an entire history. Expand only when the first capture is non-diagnostic or contradictory.

If retrieval is blocked by runtime egress, portal/session authorization, expired signature, or another environmental restriction, report the retrieval state and continue. Do not ask the user for another prompt merely to retry the same automated step unless the runtime state has changed.


1. Accept only the exact `pcap_url`/`pcap_urls` value returned by MCP.
2. Parse the URL and require `https`.
3. Treat the host as sensitive/authorized. Do not rewrite the URL, change region, or append credentials.
4. Do not print the full signed URL, JWT, query string, cookies, or Authorization header into logs or RCA output.
5. Perform a single bounded HTTP GET first. Follow redirects only when the redirect target remains HTTPS and is an explicitly allowed Mist capture/download host.
6. Accept `200` responses even when `Content-Type` is `application/octet-stream`; do NOT require `application/vnd.tcpdump.pcap` or another PCAP-specific MIME type.
7. Validate the downloaded bytes by file signature before calling it a PCAP.
8. Enforce a configurable maximum capture size and request timeout. Never stream an unbounded response into memory.
9. Store the capture in temporary storage with restrictive permissions.
10. Delete temporary capture bytes after analysis unless the operator explicitly requests retention.

## PCAP signatures

Recognize common PCAP/PCAPNG magic numbers before parsing:

- classic PCAP little-endian: `d4 c3 b2 a1`
- classic PCAP big-endian: `a1 b2 c3 d4`
- nanosecond PCAP little-endian: `4d 3c b2 a1`
- nanosecond PCAP big-endian: `a1 b2 3c 4d`
- PCAPNG: `0a 0d 0d 0a`

A response with `200` but without a recognized capture signature is `RETRIEVED_NOT_PARSEABLE` unless decompression/format handling identifies a supported capture.

## Retrieval states

Use exactly one state:

- `RETRIEVED_AND_PARSED`
- `RETRIEVED_NOT_PARSEABLE`
- `REFERENCE_RETURNED_NOT_RETRIEVED`
- `ATTRIBUTION_FAILED`

A URL that merely opens in a browser is not packet evidence. Packet analysis begins only after bytes are retrieved and validated.

## Environment failures

Distinguish:

- DNS/connection failure
- network egress/host allowlist denial
- HTTP 401/403 from Mist
- expired/invalid signed URL
- HTTP 404/410
- content-type mismatch
- invalid PCAP signature
- parser unavailable

Do not convert an infrastructure limitation into a Mist/AP/client fault.

## Analysis path

After signature validation:

1. Prefer `tshark`/Wireshark-compatible tooling if available.
2. Otherwise use an installed PCAP parser such as Scapy/PyShark if available.
3. If no parser is available, retain `RETRIEVED_NOT_PARSEABLE` and report that the bytes were obtained but packet decoding could not be performed.
4. Extract only incident-relevant packet facts.
5. Correlate packet timestamps to the MCP incident window and client/AP identity.

## Security

Signed PCAP URLs may contain bearer-like JWT material. Never include the full URL in model output, source files, persistent memory, logs, or generated reports. Redact query strings in diagnostic logs, for example:

`https://api.ac5.mist.com/api/v1/forward/download?jwt=<redacted>`

Never ask a user to paste a still-valid signed URL into a public issue tracker or TAC ticket. If a capture must be shared, share the downloaded PCAP through an approved secure channel.


## Manual-PCAP continuation

If an operator later attaches a PCAP manually, treat it as a continuation of the same evidence chain. Re-run the attribution gate against the original MCP event, validate capture format, parse packet facts, and update confidence. Manual attachment must not bypass the same timestamp/client/AP/episode controls.

## Retrieval transparency

The final investigation must distinguish: `URL discovered` → `retrieval attempted` → `bytes retrieved` → `capture validated` → `packet parser available` → `packet facts extracted`. Never collapse these states into a single "PCAP available" flag.
