---
name: investigation-context
version: 1.3.7
description: Shared context contract for every wireless investigation so all MCP queries use the same entity, time window and causal episode.
---

# Investigation Context Contract

## Purpose

Create one shared investigation context before causal correlation. Every subsequent MCP query and analysis must inherit this context unless a deliberate scope expansion is recorded.

## Required context

```text
INVESTIGATION CONTEXT
Client(s):
Site:
Area/floor:
AP(s):
WLAN/SSID:
VLAN:

Requested window:
Investigation window:
Timezone:

Incident episode(s):
Causal correlation window:

Current AP:
Historical APs:
Query/observation time:
Scope status:

Known intervention/test:
Intervention start/end:
Intervention target(s):
Expected test-generated events:
Independent post-test evidence:
```

Populate only values supported by the request or live MCP evidence. Mark unknown fields as unknown; do not guess.

## Window rules

- Use the explicit user window when supplied.
- Otherwise use an explicit incident timestamp if supplied.
- Otherwise discover the actual abnormal/failure episode from MCP telemetry.
- Use a recent window such as 24 hours only as the search envelope when no better incident window exists.
- Expand slightly before/after an identified episode only to capture causal context.
- Do not silently change the window between modules.

## Scope rules

Keep these distinct:

- requested entity/scope
- observed affected population
- investigated population
- confirmed scope classification

A site-wide search result does not make an incident site-wide. A client appearing on multiple APs does not make the APs causal.

## Context inheritance

All modules must reuse the same:

- timezone
- investigation window
- incident episode timestamps
- causal correlation window
- client/AP/WLAN/site identifiers

If a module needs to expand the window or scope, state why and record the expansion before using the new evidence.

## Display normalization

When presenting investigation results:

- Prefer the AP's human-readable **AP name** over BSSID when the MCP can resolve the historical BSSID to an AP name.
- If a BSSID is the only reliable identifier, show the BSSID and explicitly say the AP name could not be resolved. Do not guess the AP name from the current AP.
- Present timestamps in the **site-local timezone** for the affected site when the timezone is known. If multiple sites are involved, label each site's local timezone or use a clearly stated common timezone.
- Preserve the original MCP timestamp/offset internally when needed for correlation.
- Never silently mix UTC and site-local timestamps.

## Evidence timestamp rule

Every causal claim should be traceable to an event/metric timestamp inside the causal correlation window. Evidence outside that window may be background/negative evidence, but must not be presented as causal without a separate temporal justification.

## IPv4-only rule

This environment is IPv4-only. IPv6/DHCPv6 may be retained as metadata if useful, but must not be used as incident evidence, RCA support, severity evidence, or remediation justification unless the user explicitly requests IPv6 analysis.


## Controlled-test context

If a known intervention exists, it is part of the investigation context and must be inherited by all correlation modules. The context must distinguish:

- events expected because the test occurred;
- events temporally adjacent but independent of the test; and
- post-test events that demonstrate whether the symptom persisted, disappeared, or followed an entity.

Do not let a test-generated reboot/disconnect dominate RCA simply because its timestamp overlaps the incident.
