---
name: radius-analysis
version: 1.3.6
status: additive
---

# RADIUS / AAA Population and Server-Selection Analysis

## Objective

When authentication/authorization is relevant, do not analyze only the triggering client. Build an evidence-based view of which RADIUS/AAA server was actually used by APs and clients during the investigation window, and determine whether server selection correlates with failures.

This module is additive to `authentication-analysis.md`. It does not replace authentication-stage analysis.

## Mandatory investigation context

Use the shared investigation context:
- investigation start/end
- site-local timezone
- site/area
- WLAN/SSID
- AP population where known
- client population where known

Default to the investigation's established window (normally 24 hours when no better window is available). Do not silently mix windows.

## What must be established

Where MCP telemetry supports it, determine:

1. Which RADIUS/AAA server was actually selected/used by each relevant AP during the window.
2. How many APs were observed using each server.
3. Which clients authenticated through which server, including clients that are currently connected and clients that disconnected during the window when their authentication events are available.
4. Authentication/authorization outcomes per server: success, failure, timeout, retry, reject, or other exposed result.
5. Whether the same AP consistently used one server, alternated between servers, or has insufficient observations to determine a pattern.
6. Whether failures cluster by RADIUS server, AP, WLAN, client, or time.
7. Whether healthy clients successfully authenticate through the same server/path as affected clients.

## RADIUS server-selection model

The WLAN may be configured with multiple RADIUS servers and an AP/server selection or randomization behavior. Treat that configuration as expected design only. It does NOT prove which server a specific authentication transaction used.

Use the following evidence hierarchy:

```text
Actual client authentication event with server identity
        >
Actual RADIUS request/response telemetry with server identity
        >
Current MCP-visible AP/WLAN authentication-path state
        >
Static WLAN configuration / documented server pool
```

If the MCP exposes only a server pool but not the selected server for an individual transaction, report:

> Actual RADIUS server used: Not determinable from available telemetry.

Do not infer that the server was chosen randomly merely because randomization is configured.

## AP → RADIUS server mapping

For the investigation window, build an AP-level table when supported:

| AP | RADIUS server observed | Auth attempts | Success | Failure | Timeout/retry | First observed | Last observed | Pattern |
|---|---|---:|---:|---:|---:|---|---|---|

If one AP is observed using only one server, say "observed on sampled transactions" rather than claiming the AP is permanently pinned to that server.

If multiple servers are observed for the same AP, show the distribution and timestamps.

If the AP cannot be mapped to a server from live telemetry, put it in an `Unknown / not attributable` bucket.

## Client → RADIUS server mapping

For all relevant clients with authentication events in the window, build a client-level view when supported:

| Client | AP | RADIUS server | Auth time | Outcome | Failure/reason | Connected/disconnected context |
|---|---|---|---|---|---|---|

For a client that authenticates multiple times, preserve the transaction history rather than collapsing it to a single server.

Distinguish:
- initial authentication
- reauthentication
- authentication after reconnect
- authentication associated with a roam/FT event, when identifiable

A client being currently connected does not prove which server was used for its current session unless current-session telemetry exposes that relationship.

## Population summary

When the MCP permits population-level retrieval, summarize:

### AP distribution

```text
RADIUS Server A → N APs observed
RADIUS Server B → M APs observed
Unknown          → K APs
```

### Client distribution

```text
RADIUS Server A → N clients / X auth transactions
RADIUS Server B → M clients / Y auth transactions
Unknown          → K clients / Z transactions
```

Also report:
- unique APs observed per server
- unique clients observed per server
- successful transactions per server
- failed transactions per server
- timeout/retry transactions per server
- failure rate only when the denominator is actually available and comparable

Do not manufacture counts from partial client samples. If MCP cannot enumerate the requested population, state the sampling limitation.

## Connected vs disconnected clients

For a requested time window, attempt to include:
- clients with successful authentication and active/connected sessions
- clients that authenticated and later disconnected during the window
- clients with failed authentication attempts but no successful session

Do not equate `disconnected` with `authentication failure`.

A disconnected client belongs in the population because it had relevant activity during the window; its authentication outcome must be reported separately.

If the MCP cannot enumerate all clients that were connected/disconnected during the window, state exactly what population was observable.

## NAS-Identifier / AP subnet handling

If the RADIUS/NAC side uses a whole AP subnet as the NAS-Identifier, do not assume that a NAS-Identifier uniquely identifies an AP.

Use AP/client/authentication telemetry to associate an actual transaction with an AP whenever possible.

If the available telemetry exposes only the shared NAS-Identifier and server identity, report:

- shared NAS-Identifier
- RADIUS server
- number of attributable APs/clients, if derivable
- number of unattributable transactions

Do not claim AP-level server selection from a shared NAS-Identifier alone.

## Randomization / selection analysis

If multiple RADIUS servers are configured and AP randomization is enabled, explicitly answer:

1. Which servers are in the configured pool?
2. Which servers were actually observed in authentication transactions?
3. How many APs were observed using each server?
4. For each AP, how many client authentication transactions were observed through each server?
5. Does an AP appear consistently associated with one server in the observed window, or does it use multiple servers?
6. Are failures concentrated on one server, one AP, or both?
7. Are successful authentications also observed through the suspected server?

The conclusion must be based on observed transactions, not on the word "randomization" in configuration.

## Correlation rules

RADIUS correlation must distinguish:

### Server-specific pattern

Failures occur across multiple APs/clients that use the same RADIUS server, while comparable clients using another server remain healthy.

### AP-specific pattern

Failures concentrate on one AP even when that AP's authentication transactions can succeed through the same RADIUS server, or when other APs using the same server remain healthy.

### Client-specific pattern

Failures follow one client across APs/servers while comparable clients remain healthy.

### Time-specific/shared service pattern

Failures cluster at the same timestamps across multiple APs/clients and share a RADIUS dependency.

### Insufficient evidence

The server identity is unavailable, the population is incomplete, or the comparison groups are too small to distinguish hypotheses.

## Critical comparison matrix

When data permits, produce:

| RADIUS server | APs using server | Clients using server | Auth success | Auth failure | Timeout/retry | Healthy clients succeeded? | Failure concentration | Status |
|---|---:|---:|---:|---:|---:|---|---|---|

Then compare the suspected AP against peer APs using the same server.

This is particularly important when one AP appears to prefer or repeatedly select one server while nearby APs use another.

## RCA guardrails

Do NOT conclude:
- "RADIUS server is bad" merely because one AP has authentication failures.
- "NAC is the root cause" merely because authentication fails.
- "AP is faulty" merely because it uses a different server.
- "Randomization is broken" merely because an AP repeatedly uses the same server.
- "Server A is healthier" from unequal sample sizes or incomplete telemetry.

A RADIUS server becomes a strong candidate only when transaction-level, temporal, and population evidence supports the relationship.

A successful authentication through the same server is important negative evidence against a persistent server-wide failure, but does not rule out intermittent, policy-specific, client-specific, or time-specific failures.

## Minimum output for troubleshooting reports

When RADIUS analysis is material, report:

1. **Configured RADIUS pool** — only if current MCP configuration exposes it.
2. **Observed AP → RADIUS distribution** — AP names preferred over BSSIDs.
3. **Observed client → RADIUS mapping** — with timestamps in site-local timezone when known.
4. **Connected/disconnected population coverage** — what was and was not observable.
5. **Success/failure/timeout distribution by server.**
6. **Affected vs healthy comparison by server and AP.**
7. **NAS-Identifier limitation** — explicitly note if a shared AP subnet prevents unique AP attribution.
8. **Correlation result** — server-specific, AP-specific, client-specific, time-specific, or undetermined.
9. **Data gaps / minimum next MCP test.**

## Time and naming presentation

- Use site-local timezone when the site timezone is known.
- Prefer AP hostname/name over BSSID when the mapping is available.
- If only BSSID is available, show the BSSID and say AP-name mapping was unavailable.
- Never convert or guess a timestamp when the timezone is unknown.

## Automatic population view

When authentication is material, the orchestrator should not stop at the triggering client's `auth_server`. Build, for the default investigation window (24 hours unless the user specifies otherwise), the best available population view of:

- AP → observed RADIUS server distribution;
- number of APs observed using each server;
- client → RADIUS server mapping for relevant connected and disconnected authentication transactions;
- successes, rejects, timeouts and retransmissions by server where exposed;
- affected versus healthy clients using the same server; and
- whether the same AP is observed using more than one server.

If the WLAN uses server randomization, treat random selection as configuration context only. Do not infer a per-AP server choice from the configured pool. Use transaction-level `auth_server` or equivalent evidence whenever possible. Aggregate statistics with blank `ip` fields must remain unattributed.

### RADIUS conclusion guardrail

If the same RADIUS server successfully authenticates long-established or peer-AP clients while the suspect AP fails, weaken the server hypothesis and shift attention toward the AP/client exchange. If the server rejects/timeouts correlate tightly with failures across multiple APs and clients, strengthen the shared-server hypothesis. Never fill missing server identity from AP subnet/NAS-Identifier assumptions.

