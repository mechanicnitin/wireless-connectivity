---
name: rf-analysis
version: 1.3.5
description: Multi-factor RF and roaming analysis correlated to the client incident window.
---

# RF Analysis

## Collect where available

- RSSI trend
- SNR trend
- noise floor
- channel
- channel width
- channel utilization
- interference
- retries/retransmissions
- packet loss
- PHY/MCS/rates
- band
- transmit power
- RRM channel/power changes
- neighboring AP context
- roaming events
- coverage/capacity/interference SLEs

## Reasoning rules

1. Do not diagnose RF from RSSI alone.
2. Correlate RF abnormalities with exact failure timestamps.
3. Compare affected client with healthy clients on the same AP/WLAN when possible.
4. Determine whether the abnormality follows the client, AP, radio, channel, area, or site.
5. Distinguish marginal RF quality from a proven RF failure.

## Causality guardrails

- RSSI alone cannot establish RF causality.
- A degraded RF/SLE classifier is a signal to investigate, not proof of the root cause.
- RF causality requires temporal alignment with the incident plus corroborating RF/PHY evidence and, where possible, affected-vs-healthy comparison.
- A roam to a farther AP is not automatically an AP-selection failure or client defect. Roaming decisions are an interaction between client behavior, AP/RRM conditions, RF measurements, and policy. Correlate the RSSI/SNR and radio conditions at the roam decision, the APs before/after the roam, and subsequent connectivity.

## Roaming

Check:
- AP-to-AP movement
- roam frequency
- 802.11r/FT
- PMF/SA Query
- authentication around roam
- band changes
- RSSI at roam time
- post-roam DHCP/IP/connectivity behavior

## Roaming presentation

When reporting roam events, show the human-readable AP names rather than BSSIDs when the historical mapping is available. Show timestamps in the affected site's local timezone. If only BSSID or UTC is available, state the limitation rather than guessing.

## Output

State:
- Observed RF evidence
- Correlation to incident
- Competing evidence
- Scope
- RF hypothesis confidence

## AP-selection / roaming causality guardrail

Strong RSSI on one AP and weaker RSSI on the AP selected after a roam does not by itself establish an AP-selection defect, RF fault, or client fault. For each material roam, correlate:

- RSSI/SNR at the decision point
- APs before and after
- roam trigger/reason
- 802.11k neighbor information where available
- 802.11v/BSS transition or AP steering where available
- 802.11r/FT behavior where available
- channel/band/width and RF conditions
- authentication/authorization immediately before/after
- post-roam DHCP/IP/connectivity

If a client initially joins AP03 at excellent RSSI, successfully authenticates and obtains IPv4/DHCP, then immediately roams to AP04 at weaker RSSI, classify the sequence as **roam behavior requiring attribution**, not proof of an AP03 failure. Investigate whether the roam is client-driven, AP/RRM/steering-driven, or a consequence of another event.

If an AP swap/relocation test was performed, use the controlled-intervention analysis to separate physical RF/location effects from AP identity/configuration effects.

## Roam causality must remain open

A successful roam from a nearer/stronger AP to a farther/weaker AP is an **observed outcome**, not an identified cause. Keep these hypotheses open until telemetry distinguishes them:

- client roaming algorithm/policy
- RF measurement/decision
- AP/RRM/steering interaction
- 802.11k/v neighbor/transition assistance
- 802.11r/FT behavior
- band/radio preference
- load balancing
- AP-side handling of a subsequent/new association
- another trigger not exposed by MCP

Do not call the roam "RF-driven" unless the telemetry actually exposes an RF decision trigger or there is sufficient corroborating RF evidence at the decision point.

Likewise, do not call the destination AP healthier simply because the reassociation succeeded, and do not call the source AP faulty simply because the destination RSSI was worse.

## RF versus new-association behavior

When a client first authenticates successfully on AP03 at strong RSSI, then roams to AP04 at weaker RSSI, and later fails when attempting to re-enter AP03, analyze the roam and re-entry as separate episodes. The later AP03 failure may be related, but causality must be established from the event sequence.
