---
name: cross-client-analysis
version: 1.3.5
description: Affected-versus-healthy client correlation to establish scope and shared failure signatures.
---

# Cross-Client Analysis

## Population

Use the actual incident window and define the population by available telemetry/SLEs.

Correlate by:
- AP
- WLAN/SSID
- radio/band/channel
- site/area
- VLAN
- authentication method
- shared services

## Classify

A. only this client
B. multiple clients on same AP
C. multiple clients on same WLAN
D. multiple APs in same area
E. site-wide
F. multiple sites/shared service

## Control group

When possible, compare with healthy clients sharing the same AP/WLAN/site/time window.

A healthy control is valuable negative evidence. Do not generalize from a tiny sample without stating the limitation.

## Common-signature test

A candidate shared root cause should be:
- present in affected clients
- temporally aligned
- absent or less severe in controls
- technically capable of explaining the symptom

## Control-group requirements

For every material candidate shared cause, explicitly record:

- affected population size
- healthy control population size
- common AP/WLAN/radio/band/channel/site/VLAN/shared-service factors
- whether the same failure signature occurs in controls
- whether the candidate is stronger in affected clients than controls
- important exceptions/outliers

If a healthy control cannot be established, state why and reduce confidence in any scope-wide inference.

## Output

Report affected count, control count, common signatures, exceptions, what the control group rules out or weakens, and scope confidence.

## Entry-path population analysis

When the suspected mechanism involves association/authentication behavior on a specific AP, divide the population by **entry path**, not only by AP:

- long-established/stable clients
- initial/full associations
- re-entry after leaving another AP
- 802.11r/FT reassociations
- reconnects after deauthentication/disconnection

For each group, compare success and failure outcomes and, where available:
- AP
- previous AP
- authentication path (`eap`, `eap-11r`, or equivalent)
- FT/11r evidence
- PMF/security context
- session age / `time_since_assoc`
- RADIUS server
- EAP/authentication sequence
- RSSI/radio context
- client model/capability

Do not call a pattern AP-wide unless it reproduces across multiple clients or the telemetry otherwise establishes AP-level scope. A single same-client paired success/failure is a strong hypothesis generator, not sufficient population proof.

## Same-client paired comparison

When possible, compare the same client on the same AP across a successful and failed entry. Hold constant as many variables as possible and identify the minimum differentiator. Then attempt to reproduce that differentiator across other clients before raising confidence.
