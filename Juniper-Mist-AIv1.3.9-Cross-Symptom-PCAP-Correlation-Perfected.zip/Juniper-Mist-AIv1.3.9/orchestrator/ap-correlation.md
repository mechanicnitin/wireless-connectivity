---
name: ap-correlation
version: 1.3.7
description: Determines whether the issue follows a client, AP, radio, switchport, or shared infrastructure.
---

# AP Correlation

## Identify

- all APs used by the client
- current AP
- AP(s) at failure time
- AP with highest failure concentration
- APs immediately before/after failure

## For problematic AP(s), inspect where available

- online/offline
- uptime/reboots (observation only; not proof of failure)
- AP event history around reboot timestamps
- available administrator/audit/change logs for manual reboot, maintenance, configuration, or other operator actions
- alarms/entity events
- SLEs
- radio health
- channel/utilization/interference
- RRM changes
- PoE/power constraints
- connected switch
- switchport
- LLDP
- speed/duplex
- errors/discards/flaps
- VLAN/configuration
- AP/client MAC learning
- relevant ARP

## Uptime/reboot attribution rule

A lower uptime means the AP rebooted more recently; it does not by itself establish AP failure. Before treating the reboot as causal, correlate the reboot timestamp with AP events and available administrator/audit/change logs. If logs show a manual/maintenance/configuration reboot, classify that as an observed administrative action rather than an AP fault unless additional telemetry proves a fault.

## Decision test

Ask:
1. Does the issue follow the client across APs?
2. Do other clients fail on the same AP?
3. Do healthy clients remain normal on the same AP?
4. Do multiple APs share the same abnormality?
5. Is there a common switch, VLAN, WLAN, AAA, DHCP/DNS, or site dependency?

Do not label AP-specific merely because the failure occurred on an AP.

## AP identity vs physical-location isolation

When an AP is moved, swapped with another AP, or replaced, explicitly compare **AP identity/configuration** against **physical location**. If the symptom follows the AP identity after relocation while the replacement AP behaves normally in the former location, classify this as strong AP-specific evidence, but do not yet select hardware, firmware, configuration, radio, or authentication-path mechanism without further telemetry.

A short uptime or reboot is not an AP-failure diagnosis. Check AP events and available admin/audit/change logs to determine whether the reboot was manual, maintenance-driven, configuration-driven, power-related, software-related, or fault-related.

## AP identity versus location

For a suspected AP-specific problem, automatically compare the suspect AP with at least one peer AP serving the same WLAN and, when available, the same client. Include firmware, model, hardware revision, WLAN/security configuration, RADIUS path, radio/channel, switch/port, uptime and reboot/admin history where exposed.

When the suspect AP is physically replaced or moved, treat the old-location replacement and moved-suspect-AP results as a controlled intervention. If the symptom follows the AP identity and the replacement works in the old location, this is strong AP-specific evidence. If the symptom remains at the location, prioritize RF/environment/location hypotheses. If both change, report the confound rather than forcing an RCA.

Short uptime or a recent reboot is an observation, not a cause. Check admin/config-change events and reboot sequence before using it in causal reasoning.



## Controlled replacement / relocation precedence

When an AP has been deliberately replaced, moved, or swapped, first determine whether recent reboot/disconnect events are **test-generated**. A replacement AP may legitimately show a restart, disconnect, reconnect, config-change, or short-uptime signature because it was intentionally introduced. Do not increase its fault likelihood from those events alone.

Use this evidence hierarchy for AP-specific attribution:

1. Controlled before/after intervention result.
2. Direct client/AP failure telemetry.
3. Peer/healthy-client comparison.
4. Independent AP health/reboot/admin evidence.
5. Temporal coincidence and contextual anomalies.

Lower-level temporal anomalies must not override a higher-quality controlled experiment.
