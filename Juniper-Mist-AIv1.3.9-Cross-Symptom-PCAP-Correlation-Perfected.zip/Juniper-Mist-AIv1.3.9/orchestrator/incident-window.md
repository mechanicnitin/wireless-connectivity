---
name: incident-window
version: 1.3.4
description: Establishes the actual causal investigation window instead of blindly analyzing an arbitrary recent period.
---

# Incident Window

## Goal

Analyze the last 24 hours by default only when no better window exists. The causal window is the period where the symptom/failure actually occurred.

## Priority

1. Explicit user time window
2. Explicit incident timestamp
3. MCP event/SLE evidence identifying failure episodes
4. Recent window supported by available telemetry

## Procedure

1. Query the broadest reliable client/site event view.
2. Find failure/degradation clusters.
3. Group temporally adjacent events into episodes.
4. Record episode start/end, count, and recurrence.
5. Expand slightly before and after each episode for causal context.
6. Use the same episode timestamps when correlating AP, RF, WLAN, SLE, RADIUS, DHCP, DNS, wired, and change data.

## Output

```text
Investigation window: <actual window>
Incident episodes:
- Episode 1: <start>–<end>, <count>, <signature>
- Episode 2: ...

Causal correlation window: <expanded window if used>
```

Never correlate an unrelated event merely because it falls inside the 24-hour reporting window.
