---
name: telemetry-collection-contract
version: 1.3.7
description: Normalized live-telemetry requirements derived from the master investigation prompt; defines what the orchestrator should try to collect without forcing a fixed command sequence.
---

# Telemetry Collection Contract

## Purpose

This file converts the master wireless investigation requirements into a reusable evidence contract. It is a collection target, not a giant prompt and not a mandatory list of one-query-per-domain commands.

For troubleshooting, collect the best available live Juniper Mist MCP evidence across the domains below before final RCA. Reuse evidence already returned by earlier queries.

## Symptom coverage

The collection contract applies across common wireless user symptoms, including slowness/poor throughput, inability to connect, association failure, authentication failure, repeated disconnects, roaming/walking dropouts, poor voice quality, high ping/latency, missing IPv4 address, and site-wide or multi-client wireless degradation. The symptom does not limit collection to one domain.

## Collection domains

### 1. Client identity and state

Collect where available:
- MAC/client identifier
- hostname
- OS/device type
- username/identity
- site/building/floor/area
- WLAN/SSID
- VLAN
- IPv4 address
- current and historical APs
- band/radio/channel/channel width
- RSSI/SNR/noise
- PHY/Tx/Rx rates/MCS
- session/uptime
- authentication method and key management

### 2. Incident and event timeline

Collect:
- first abnormal event
- first confirmed failure
- incident episode start/end
- recurrence/count/duration where available
- association/reassociation
- authentication/802.1X/EAP/authorization
- RADIUS
- deauthentication/disassociation
- roaming/FT/PMF/SA Query
- RF events
- DHCP/IPv4
- ARP/gateway
- DNS/connectivity
- SLE/entity/action events
- relevant AP/wired/changes events

For significant events retain timestamp, event type, reason/status, AP/WLAN/band and useful before/after context.

### 3. RF and radio

Collect where available:
- RSSI/SNR trends
- noise floor
- channel utilization
- interference
- retries/retransmissions
- packet loss
- PHY/rates/MCS
- channel width/band/channel
- transmit power
- RRM/channel/power changes
- neighboring AP context
- coverage/capacity/interference SLEs

RF is a hypothesis domain until it is temporally and technically correlated with the incident.

### 4. Association and roaming

Collect:
- association/reassociation success/failure
- reason/status codes
- roam events and frequency
- AP-to-AP movement
- band changes
- 802.11r/FT
- PMF/SA Query
- authentication/deauthentication around roams
- RF state at roam time

### 5. Authentication / authorization / AAA

Collect:
- authentication successes/failures
- authorization successes/failures
- EAP method/reason/status
- RADIUS request/response/timeout/retry indicators
- server health/reachability where exposed
- WLAN security/policy context
- VLAN/role attributes where exposed
- behavior across APs and across other clients

Do not infer certificate, credential, RADIUS policy, ClearPass, PMKID or similar specific causes without telemetry supporting that mechanism.

### 6. AP / radio / wired path

For relevant APs collect where available:
- online/offline state
- uptime/reboots
- AP event history around reboot timestamps
- administrator/audit/change records where exposed
- alarms/events
- radio health
- utilization/interference
- RRM activity
- PoE/power state and constraints
- connected switch/port
- link state/speed/duplex
- LLDP
- interface errors/discards/flaps
- AP/client MAC learning
- VLAN/configuration
- relevant ARP

Determine whether the issue follows the client or remains localized to an AP/radio/path.

### 7. Other clients and healthy controls

During the same incident window, identify:
- affected clients
- healthy controls
- AP/WLAN/radio/band/channel/site/area/VLAN/authentication commonalities
- common failure signatures
- exceptions

A shared cause should be present or materially stronger in affected clients, temporally aligned, technically capable of explaining the symptom, and ideally less prevalent in controls.

### 8. WLAN / site / shared services

Correlate during the actual incident window:
- authentication/authorization
- association/roaming
- RF/coverage/capacity/interference
- DHCP/IPv4
- ARP/gateway
- DNS/connectivity
- AP health
- wired infrastructure
- SLE classifiers/sub-classifiers
- WLAN configuration
- shared RADIUS/DHCP/DNS/VLAN/switching/WAN dependencies
- same WLAN/VLAN/service at other sites where relevant

Do not import another site's failures merely because they exist; identify the shared dependency first.

### 9. Recent changes

Collect where available:
- WLAN/security/RADIUS changes
- AP/RF/RRM/channel/power changes
- switchport/VLAN changes
- DHCP/DNS changes
- firmware/software changes
- site/network changes
- relevant user/admin/configuration changes
- administrator/audit records for manual AP reboot or maintenance/configuration actions

A change is a candidate cause only when timing, dependency, scope and post-change telemetry align.


### 10. Packet-capture evidence

When live MCP events expose `pcap_urls` or equivalent packet-capture references, collect the reference as evidence metadata and attempt retrieval only if the available runtime supports authorized access. For each capture retain:
- source MCP event and event timestamp
- client identity
- AP/BSSID identity
- WLAN/site when exposed
- capture URL/reference exactly as returned
- capture start/end or packet timestamp range when available
- retrieval/parse status
- protocol facts relevant to the incident

Relevant packet layers may include:
- 802.11 association/reassociation and status codes
- RSN/PMF and security negotiation
- 802.11r/FT/FT authentication or reassociation
- EAPOL/802.1X
- DHCP/IPv4
- ARP/ICMP and gateway reachability
- retransmissions/timing where visible
- application/voice packets only when the capture actually contains them and analysis is appropriate

Do not infer packet-level facts that are not present. Do not download arbitrary URLs, follow rewritten URLs, or associate a capture with another client/AP merely because it is temporally nearby.

## Evidence semantics

Every collected item should be treated as one of:

- **Observed** — directly returned by live MCP telemetry.
- **Documented** — static expected design/context.
- **Correlated** — multiple observed facts align by time/entity/dependency.
- **Inferred** — reasoned hypothesis based on evidence.
- **Ruled out / weakened** — evidence materially contradicts a candidate.
- **Unknown / data gap** — required evidence unavailable.

## Query discipline

- Do not run redundant queries when prior MCP output already contains the required evidence.
- Do not force a domain-specific query when that domain is irrelevant to the actual incident or already answered.
- Do not fabricate a field because the contract lists it.
- If a domain cannot be observed through MCP, record the gap and continue.
- The contract does not prescribe exact MCP tool names or command syntax.


## Human-readable correlation output

For timelines and roam paths, prefer resolved AP names over BSSIDs and site-local timestamps over UTC when the mapping/timezone is available. Retain BSSID and original timestamp as underlying evidence. Never guess an AP name or timezone.
