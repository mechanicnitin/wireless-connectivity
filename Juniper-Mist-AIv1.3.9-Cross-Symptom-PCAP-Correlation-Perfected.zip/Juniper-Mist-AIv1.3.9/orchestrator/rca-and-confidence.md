---
name: rca-and-confidence
version: 1.3.7
description: Evidence classification, root-cause ranking, confidence and next-test logic.
---

# RCA and Confidence

## Evidence labels

- **Observed** — directly returned by current MCP/live telemetry.
- **Documented** — static knowledge/design information.
- **Correlated** — two or more observed facts align by time/entity/dependency.
- **Inferred** — reasoned conclusion from evidence.
- **Unknown / Data Gap** — unavailable, inaccessible, or not verified.

## Evidence sufficiency gate

Before assigning **Confirmed Root Cause** or **Most Likely Root Cause**, verify:

- actual incident window established
- timeline is coherent and event attribution is verified
- relevant domains attempted or documented as unavailable
- affected and healthy control populations compared where possible
- AP uptime/reboot events checked against AP telemetry and available admin/audit logs when relevant
- supporting and contradicting evidence recorded
- competing hypotheses considered

If a material item is missing or contradictory, use **Root Cause Not Confirmed** and state the evidence boundary.

Observed failure ≠ root cause. A correlated abnormality ≠ root cause. A plausible mechanism ≠ confirmed causality.

## Root-cause status

Use exactly one:

### Confirmed Root Cause
Direct evidence establishes causality.

### Most Likely Root Cause
Multiple observations strongly support the hypothesis, but direct proof is incomplete.

### Root Cause Not Confirmed
Evidence is insufficient, contradictory, or key telemetry is unavailable.

## Candidate ranking

For each candidate, score qualitatively across:
- temporal alignment
- dependency fit
- scope match
- affected-vs-healthy contrast
- directness of evidence
- competing evidence

Do not manufacture numeric confidence scores unless the MCP itself supplies a validated score.

## Root-cause table

| Candidate | Supporting evidence | Contradicting evidence | Scope | Status/confidence |
|---|---|---|---|---|
| ... | ... | ... | ... | ... |

## Closure decision

A troubleshooting investigation may close only when either:

1. evidence is sufficient for a defensible RCA, or
2. the MCP evidence boundary has been reached and the exact missing test/evidence is stated.

Never close with a confident RCA simply because the report has a plausible narrative.

## Minimum next test

If RCA is not confirmed, request the smallest additional MCP query that can distinguish the top remaining hypotheses. Avoid random troubleshooting.

## Fix safety

Recommend actions; do not silently execute destructive/configuration changes.

## Controlled-intervention evidence

A controlled intervention can materially change confidence. Controlled-test results have higher causal value than simple temporal coincidence. A reboot/disconnect/config-change event that is an expected consequence of the intervention is context, not independent fault evidence. A symptom following AP identity after an AP relocation/swap is strong correlated evidence for an AP-specific problem, while a symptom remaining at the physical location strengthens environmental/RF hypotheses. Neither result alone identifies the exact mechanism.

For AP-selection cases, do not treat weaker RSSI on the destination AP as proof of client error or AP failure. The root cause must explain the actual roam decision and any authentication/association behavior around it.

## Mechanism-versus-correlation guardrail

Do not promote a correlated field difference into a mechanism without a discriminating test.

Examples:
- `eap` failure vs `eap-11r` success establishes an entry-path correlation; it does not prove an 11r defect.
- Strong source RSSI followed by a weaker destination RSSI establishes a roam outcome; it does not prove why the client roamed.
- AP-specific auth failures establish scope only after cross-client/AP comparison; they do not prove AP hardware/firmware fault.
- A RADIUS server identity on a failed transaction does not prove server causality unless server-side response/timeout/reject evidence or a strong peer comparison supports it.

## Minimum differentiating factor

For each top hypothesis, state:
1. the observed difference;
2. what mechanism that difference could explain;
3. what evidence would be expected if the mechanism were true;
4. what evidence would falsify it;
5. the smallest MCP test that distinguishes it from the next-best hypothesis.

A single paired client comparison can raise a hypothesis to **strong correlation**, but AP-wide RCA requires replication across additional clients or independent AP-level evidence.

## AP-specific evidence versus mechanism

A controlled AP replacement/relocation that makes the symptom follow the AP identity is **strong AP-specific RCA evidence**. It is not, by itself, proof of an internal mechanism such as an 802.11r key-holder defect, EAPOL relay bug, RF issue, or hardware failure.

For AP-specific authentication findings, the preferred evidence ladder is:

1. Same WLAN/configuration and firmware/model parity.
2. Same client succeeds on peer AP(s).
3. Suspect AP repeatedly fails comparable entry attempts.
4. Healthy clients can be compared on the suspect AP.
5. RADIUS server/path is shared and healthy elsewhere.
6. AP replacement works in the old location.
7. Suspect AP reproduces the symptom after relocation.

When steps 1–7 align, the response may recommend AP-focused TAC escalation with high confidence in **scope** while explicitly marking the **mechanism** as unconfirmed unless direct AP telemetry proves it.

