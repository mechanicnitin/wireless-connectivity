---
name: network-path-analysis
version: 1.3.4
description: IPv4 post-authentication path analysis from VLAN/IP through ARP, gateway, DNS and network reachability.
---

# Network Path Analysis

## Dependency path

```text
Authentication
 → VLAN/role
 → DHCP/IPv4
 → ARP
 → Default gateway
 → DNS
 → Network/WAN
 → Application
```

## Latency / reachability

For high-ping/latency symptoms, distinguish client-to-AP/RF timing, gateway/ARP timing, wired/WAN path latency, and application latency. Use packet evidence only when the capture contains the relevant traffic. Do not infer WAN/application latency from an unrelated wireless event.

## DHCP / IPv4

Check:
- DHCP success/failure
- latency/timeouts/retries where available
- IP assignment
- subnet/VLAN
- gateway
- lease details
- affected vs healthy clients on same VLAN

## ARP / gateway

Check:
- ARP presence/state
- IP-to-MAC consistency
- gateway reachability
- incomplete/stale entries where exposed

Do not expect ARP evidence if the client never received an IPv4 address.

## DNS

Investigate only after usable IPv4 connectivity is established.

Separate DNS failure from general network failure.

## IPv6 policy

This environment is IPv4-only. Ignore IPv6/DHCPv6 telemetry unless the user explicitly requests it. Never recommend changing IPv6 settings based only on telemetry in the normal wireless RCA.
