---
name: site-correlation
version: 1.3.4
description: Site/WLAN/SLE/shared-service correlation for wireless incidents.
---

# Site Correlation

## Check during the actual incident window

- Successful Connects / relevant Wireless SLEs
- authorization/authentication
- association
- roaming
- coverage
- capacity/interference
- DHCP/IPv4
- ARP
- DNS
- gateway/connectivity
- AP health
- AP events
- wired infrastructure
- Marvis/entity/action events where available
- configuration/firmware changes

## SLE rule

A degraded SLE is a lead, not a root cause. Correlate:
- exact timestamp
- affected clients
- AP/WLAN concentration
- failure classifier/sub-classifier
- event signatures

## Shared dependency analysis

If multiple APs or sites are affected, test common dependencies such as:
- WLAN configuration
- AAA/RADIUS
- DHCP
- DNS
- VLAN/forwarding
- switching/uplinks
- WAN/shared services
- common configuration changes

## Multi-site caution

Do not pull failures from another site into the incident merely because a broad query returned them. Keep site scope explicit and explain when a shared-service hypothesis makes another site relevant.
