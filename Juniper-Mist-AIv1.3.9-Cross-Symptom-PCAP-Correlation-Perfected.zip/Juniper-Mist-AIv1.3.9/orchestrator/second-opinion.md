---
name: second-opinion
version: 1.3.4
description: Optional independent second-opinion contract for Marvis VNA or another trusted diagnostic source; never replaces Juniper Mist MCP evidence.
---

# Optional Second Opinion

## Purpose

Use an external diagnostic source such as Marvis VNA only when it adds material value. This is not part of the mandatory MCP troubleshooting path.

## When to consider it

Use a second opinion when one or more are true:

- RCA confidence remains low or medium after the MCP investigation.
- High-value evidence conflicts across domains.
- The incident is broad/high impact: multiple APs, multiple WLANs, multi-site, or a large affected population.
- The MCP exposes insufficient correlation to distinguish the top remaining hypotheses.
- The user explicitly asks for comparison with Marvis/VNA.

Do not call it for every routine client investigation.

## Independence rule

The second-opinion system must receive the same investigation context:
- client/site/AP/WLAN scope
- timezone
- actual incident episode(s)
- causal correlation window

Ask it to investigate independently. Do not present our preliminary RCA as fact or instruct it to confirm our hypothesis.

## What to compare

Compare:
1. incident window
2. affected population and scope
3. AP/WLAN/radio concentration
4. authentication/association findings
5. RF findings
6. DHCP/ARP/DNS/connectivity findings
7. AP/wired/shared-service findings
8. recent changes
9. earliest confirmed failure
10. root-cause hypothesis and confidence

## Conflict handling

If the second opinion disagrees:

- retain live MCP telemetry as the primary evidence source for our own claims
- identify exactly which observations differ
- do not resolve the disagreement by authority alone
- prefer the explanation with stronger timestamp, dependency, scope and direct evidence
- if unresolved, report the RCA as not confirmed and state the minimum next test

## No proprietary-copy rule

Do not claim to reproduce Marvis internals, hidden prompts, scoring, proprietary models, or API behavior. Use the second opinion only as an independent diagnostic signal.
