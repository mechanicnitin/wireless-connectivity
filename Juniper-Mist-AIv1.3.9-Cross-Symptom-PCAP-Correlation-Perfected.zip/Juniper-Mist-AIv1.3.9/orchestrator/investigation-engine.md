---
name: investigation-engine
version: 1.3.9
description: Top-level evidence-driven wireless investigation engine. Mirrors the useful observable behavior of Marvis troubleshooting without depending on Marvis VNA output.
---

# Investigation Engine

## Objective

For a troubleshooting request, perform a broad evidence pass across every relevant wireless failure domain first, then perform focused deep-dive queries only where the baseline evidence, scope, or uncertainty requires them.

"Broad" means attempt to establish the state of every relevant domain; it does not mean blindly execute every possible query. If a domain is not exposed by MCP, record the data gap and continue.

Do not ask the user to enumerate RF, DHCP, DNS, authentication, AP, or wired checks. The engine owns the correlation.

## Mandatory contracts

Before causal analysis, load:
- `orchestrator/investigation-context.md`
- `orchestrator/telemetry-collection-contract.md`

If a second opinion is explicitly requested or justified by the rules, load `orchestrator/second-opinion.md` only after the MCP-first investigation.

## Investigation lifecycle

```text
User symptom / request
        ↓
Resolve entities + window
        ↓
Normalize symptom → evidence domains
        ↓
Build client/site baseline
        ↓
Find actual incident episodes
        ↓
Build chronological event timeline
        ↓
Recognize controlled test/intervention context
        ↓
Evaluate dependency chain
        ↓
Correlate RF + AP + wired + shared services
        ↓
Compare affected vs healthy clients
        ↓
Correlate site/WLAN/SLE/changes
        ↓
Automatically attempt packet-capture corroboration when `pcap_urls` are exposed
        ↓
        Record retrieval/parse state even when blocked
        ↓
        ↓
Identify earliest confirmed failure
        ↓
Rank hypotheses
        ↓
Select focused playbook(s)
        ↓
Recommend minimum next action
        ↓
Return structured evidence-based result
```

## Automatic PCAP closure rule

If a material event has a `pcap_url`/`pcap_urls`, the engine must attempt retrieval automatically before final RCA. A second user prompt is not required. If retrieval is blocked, the closure gate may still pass only if the remaining MCP evidence is sufficient; the report must explicitly state that packet corroboration was unavailable. If the PCAP is manually attached later, ingest it and update the evidence chain.

## Evidence Sufficiency / Closure Gate

Before declaring RCA, the investigation must pass a closure gate. Do not stop merely because one plausible explanation has appeared.

### Closure gate

1. **Context complete:** entity, site/area where relevant, investigation window, timezone, and incident episode are established or explicitly unknown.
2. **Timeline coherent:** significant events are chronologically ordered and any contradictions or attribution ambiguities are resolved or documented.
3. **Broad evidence attempted:** all material domains in the telemetry collection contract have been checked, reused from existing MCP evidence, or explicitly recorded as unavailable/not applicable.
4. **Scope tested:** affected population and healthy control population are compared where MCP permits.
5. **Dependency tested:** the earliest confirmed broken dependency is distinguished from symptoms and contributors.
6. **Candidate causes challenged:** each material RCA hypothesis has supporting and contradicting evidence.
7. **AP uptime/reboot ambiguity closed:** a short AP uptime is never treated as an AP failure by itself. When relevant, check AP events and available admin/audit/change logs for a manual reboot or configuration action before attributing causality. If the reboot/disconnect is an expected consequence of a documented replacement or test, classify it as test-generated context and remove it from independent fault scoring.
8. **Closure decision:** either (a) evidence supports a defensible RCA, or (b) the investigation reaches an explicit evidence boundary and names the minimum missing MCP evidence/tests.

If any material gate item fails, do not present the RCA as confirmed. State **RCA not yet confirmed** and continue with the minimum evidence needed when MCP can provide it.

## Symptom normalization contract

The user's wording is not the investigation boundary. Normalize common symptoms into candidate domains, then validate all relevant dependencies:

| User symptom | Minimum domains to examine |
|---|---|
| “Wi-Fi is slow” / poor throughput | client performance, RF, roaming, AP/radio load, IPv4/network path, application/SLE evidence where available |
| “I cannot connect to Wi-Fi” | visibility, association, authentication/authorization, DHCP/IPv4, AP/RF, scope and shared dependencies |
| “I lose connection when I walk around” | roam timeline, leave decision, roam execution, FT/11r, PMF, RF, destination entry/authentication, AP selection |
| “I get disconnected all the time” | disconnect timeline/reasons, RF, roaming, AP health, authentication, DHCP/IP continuity, scope |
| “Voice quality is bad” | latency, jitter, packet loss/retransmissions, RF, airtime/load, roaming interruptions, gateway/path, application/meeting/voice telemetry where exposed |
| “Ping is high” | client/AP RF, retries, airtime, gateway/ARP, wired/WAN path, packet loss, time correlation; distinguish RTT from application latency |
| “Cannot associate” | association events/reasons, RF, AP health/path, security/RSN/PMF/FT context where exposed |
| “Cannot authenticate” | association first, EAP/802.1X, RADIUS/AAA, auth path, FT fallback, PMF/security context, peer-AP controls |
| “Not getting an IP” | association/authentication first, DHCP/IPv4, VLAN/role, relay/gateway, affected VLAN/client scope |

This table is a routing aid, not a causal decision tree. Always establish the earliest confirmed failure and challenge competing hypotheses.

## Packet-capture escalation

When an MCP event includes `pcap_urls` or an equivalent capture reference:

1. Preserve the exact event timestamp, client, AP/BSSID, WLAN and event type that produced the reference.
2. Validate that the capture belongs to the incident episode before analysis.
3. Retrieve the capture only through an available authorized/runtime-supported mechanism; never guess or rewrite the URL.
4. Parse/inspect the capture for the protocol layers relevant to the failure: 802.11 association/reassociation, RSN/PMF, 802.11r/FT, EAPOL/802.1X, DHCP, ARP and other packet evidence appropriate to the symptom.
5. Correlate packet timestamps with MCP events and RADIUS telemetry when available.
6. Prefer structured packet facts (frame type, status, retransmission, missing/expected response, EAP method/result, timing) over unsupported narrative guesses.
7. Use PCAP to raise or lower confidence in a hypothesis; do not treat packet presence alone as proof of root cause.
8. If the capture is unavailable, incomplete, truncated, encrypted beyond useful visibility, or not attributable to the event, record the limitation and continue with non-PCAP evidence.

PCAP can establish what was observed on the capture path. It does not automatically establish what happened inside the AP, RADIUS server, switch, client supplicant or application unless the relevant packets/telemetry actually expose it.

## Evidence-first rule

Collect raw/structured MCP evidence before writing RCA prose. Preserve:
- timestamp
- entity
- event type
- reason/status code
- AP/WLAN/site
- relevant metric values
- success/failure state
- source/tool used

Do not fabricate missing fields.

## Progressive query strategy

Use a two-layer strategy:

**Layer 1 — Broad baseline (mandatory for troubleshooting):**
Attempt to establish client state, incident episodes, timeline, APs, association, authentication/authorization, RADIUS server-selection/population mapping where supported, RF/roaming, IPv4/DHCP/ARP/gateway, DNS, AP health/power/wired path, cross-client scope, WLAN/site/SLE behavior, and recent changes.

**Layer 2 — Focused deep dive (conditional):**
After the baseline, branch into the relevant playbook/domain modules to resolve the first confirmed failure, explain the symptom, distinguish competing hypotheses, or fill a material data gap.

Do not skip a domain merely because the user's wording suggests a different domain.

1. Client identity/current state
2. Actual incident window
3. Client event timeline
4. First-pass SLE/connectivity indicators
5. AP(s) involved
6. RF/roaming/association
7. Authentication/RADIUS
8. RADIUS population/server-selection correlation (`orchestrator/radius-analysis.md`) when authentication/RADIUS is material
9. DHCP/IPv4/ARP/gateway
9. DNS
10. AP health/power/wired path
12. Other-client correlation
13. WLAN/site/shared-service correlation
14. recent changes

If a single MCP result already answers a branch, do not repeat the same query unnecessarily. "Attempt" means obtain the best available MCP evidence for that domain; it does not require a separate query when the evidence is already present.

## Dependency chain and cross-cutting domains

Use the following as the post-association dependency chain:

```text
Client state
 → AP association
 → Authentication / 802.1X
 → Authorization / AAA result
 → VLAN / role
 → IPv4 / DHCP
 → ARP / gateway
 → DNS
 → Network / WAN
 → Application / service connectivity
```

RF/radio quality, AP health, PoE, wired path, WLAN health, SLEs, scope and shared services are **cross-cutting evidence domains**, not necessarily sequential failure stages. Correlate them against the actual incident timestamps and dependency stage.

## First confirmed failure

For each incident episode, identify the earliest dependency that is actually proven broken. Keep these distinct:
- first abnormal observation
- first observed failure event
- earliest confirmed broken dependency
- downstream symptoms/consequences

A candidate contributor can exist before the first confirmed broken dependency without itself being proven causal.

For authentication investigations, load `orchestrator/radius-analysis.md` to produce AP→RADIUS and client→RADIUS mappings and population-level server distribution when MCP telemetry permits.

Do not classify:
- deauthentication as authentication failure without authentication evidence
- authorization failure as generic association failure
- DNS failure as lack of IP connectivity
- low RSSI as proven RF root cause
- site SLE degradation as client causality

## Focused playbook handoff

After the broad baseline, select one or more focused playbooks only when supported by evidence:

- association failure → `playbooks/association-failure.md`
- authentication/authorization failure → `playbooks/authentication-failure.md`
- DHCP/IPv4 failure → `playbooks/dhcp-failure.md`
- DNS failure → `playbooks/dns-failure.md`
- AP down/unreachable → `playbooks/ap-down.md`
- AP wired-path/PoE/switchport issue → `playbooks/ap-switchport.md`
- repeated disconnects → `playbooks/client-disconnection.md`
- RF/performance degradation → `playbooks/rf-performance.md`
- client slowness/poor performance → `playbooks/client-performance.md`

A symptom may require multiple playbooks. Do not use the playbook name as proof of root cause.

## Scope decision

Classify as:
- CLIENT-SPECIFIC
- AP-SPECIFIC
- WLAN-SPECIFIC
- AREA/MULTI-AP
- SITE-WIDE
- MULTI-SITE/SHARED-SERVICE
- UPSTREAM/INFRASTRUCTURE
- UNDETERMINED

Scope is evidence, not causality.

## IPv4-only environment

Ignore IPv6 and DHCPv6 events unless explicitly requested. Do not use IPv6/DHCPv6 telemetry in RCA, severity, or recommended actions for this environment.

## Observable investigation behavior, without Marvis dependency

The engine should reproduce the *observable investigation pattern* supported by Juniper documentation:
- use SLE classifiers and timelines to identify where failures occur
- identify affected devices and when they were affected
- compare concentration across APs/WLANs/device types
- use client/AP events for detail
- correlate trends and event timelines
- use structured query capability when useful
- use a shared context and stable causal window across all queries
- compare affected and healthy populations where possible
- treat Marvis/VNA output as an optional independent second opinion if separately available, never as a replacement for MCP evidence

Do not claim to reproduce proprietary internal Marvis models or scoring.

## Controlled intervention branch

If the user reports a deliberate troubleshooting intervention (reboot, AP swap/relocation, replacement, cable/port change, configuration rollback, RADIUS-path change, or controlled client comparison), load `orchestrator/controlled-intervention-analysis.md`. Treat the intervention as causal evidence only after comparing the before/after states and identifying what changed versus what remained constant.

For AP-selection/roaming cases, explicitly test both dimensions: **AP identity/configuration** and **physical location/RF environment**. A problem that follows an AP after physical relocation is materially different evidence from a problem that remains at a physical location.

## Entry-path and behavior-separation analysis

For investigations involving roaming, AP preference, or AP-specific authentication behavior, create separate evidence tracks for:

1. **Roam decision** — why the client left the source AP.
2. **Roam execution** — whether the destination reassociation/FT completed successfully.
3. **Destination entry** — whether the client subsequently attempted a fresh/new association to the source AP or another AP and whether that attempt succeeded.
4. **Established-session behavior** — whether an already-authorized client remained healthy on the AP.

Do not merge these tracks into a single RCA chain merely because they occur close together in time.

### Minimum differentiator test

When an AP appears problematic, compare at least one successful and one failed entry to the same AP where possible. Prefer same-client, same-AP paired evidence before broad generalization. Compare:

- previous AP / current AP
- initial association vs reassociation/roam
- `auth_type` or equivalent authentication path
- 802.11r/FT status
- PMF/security context when exposed
- `time_since_assoc` or equivalent session-age context
- RADIUS server identity and transaction outcome
- EAP/authentication event sequence
- RSSI/SNR and radio context
- timestamps and site-local timezone
- client model/capability where exposed

Ask: **what is the minimum factor that differs between the successful and failed paths?** A correlated difference is a hypothesis, not automatically the mechanism.

### Hypothesis challenge

For every leading hypothesis, explicitly ask what evidence should also be present if it were true and what evidence would falsify it. In particular, do not convert:

- `eap` vs `eap-11r` into an automatic "11r fault" conclusion;
- a successful roam at weaker RSSI into an automatic RF/client/AP-selection conclusion;
- an authentication failure into an automatic RADIUS-server conclusion.

If the MCP cannot distinguish these possibilities, reach an evidence boundary rather than inventing the missing mechanism.

## Automatic deep client/AP investigation contract

For a named-client troubleshooting request, do not wait for the user to enumerate sub-questions such as “check 11r”, “check RADIUS”, or “compare AP03/AP04”. The orchestrator must automatically build the deepest available evidence set before RCA:

1. Resolve the client, WLAN, site and local investigation window.
2. Build the client's chronological AP sequence, including previous/current/next AP where exposed.
3. Correlate association, reassociation, authentication/802.1X/EAP, RADIUS, 802.11r/FT, PMF/SA Query, deauth/disassoc, RF metrics and timestamps.
4. Split episodes into **leave/roam decision**, **roam execution**, **destination entry/authentication**, and **established-session behavior**.
5. For AP-specific authentication symptoms, automatically compare: (a) same client on the suspect AP, (b) the same client on peer APs, (c) healthy/long-established clients on the suspect AP, and (d) successful and failed entry paths on the same AP.
6. When `auth_type`, FT events, capability fields, or equivalent telemetry exist, explicitly compare `eap`/full-EAP, `eap-11r`/FT, ordinary reassociation, and pre-EAP association failures.
7. Correlate each relevant authentication event to the actual RADIUS server identity and outcome when exposed, and invoke the RADIUS population analysis for AP→server and client→server distribution.
8. If an AP swap/replacement/relocation is reported, automatically load the controlled-intervention analysis and compare symptom-by-AP-identity versus symptom-by-location.

The output must state the **minimum reproducible differentiator** between success and failure and identify whether it is merely a correlation or a tested mechanism.

## Timeline attribution gate

Before an event is used as AP-specific RCA evidence, verify as many of these as MCP exposes: exact timestamp, client identity, AP/BSSID identity, event type, WLAN, and immediate preceding/following events. If an event is only adjacent in a client timeline but is attributed to another AP, do not assign it to the suspect AP. If attribution remains ambiguous, mark it as an evidence gap.

## AP replacement / relocation control

When a suspect AP is replaced by a known-good AP in the original location and the suspect AP is moved to a different location, treat the experiment as a high-value controlled intervention. Compare the same client/WLAN and entry behavior before and after, keeping firmware/model/configuration/RADIUS/WLAN constants explicit. If the problem follows the AP identity while the replacement works in the original location, strongly raise AP-specific scope while keeping the internal mechanism unproven.



## Controlled intervention precedence in RCA

When the investigation includes an AP replacement/swap/relocation, the intervention result is a high-value control. Do not let a test-generated restart, disconnect, reconnect, config-change or short-uptime event cause the replacement AP to receive a high fault score. Score AP identity versus location first, then evaluate independent post-test failures.

A pattern such as:

`old location + replacement AP = healthy`
`new location + suspect AP = same failure`

should produce **strong AP-identity evidence** while keeping the internal mechanism unconfirmed.

The engine must also challenge this evidence against broader scope. A site-wide/shared failure does not automatically erase a valid AP-specific controlled experiment; instead report two layers: `shared background condition` and `AP-specific differential effect`, if both are supported.
