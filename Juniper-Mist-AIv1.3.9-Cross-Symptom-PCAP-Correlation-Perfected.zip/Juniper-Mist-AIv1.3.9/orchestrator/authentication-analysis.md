---
name: authentication-analysis
version: 1.3.7
description: Authentication, authorization, 802.1X/EAP and RADIUS analysis without overclaiming from generic disconnect events.
---

# Authentication Analysis

## Determine the exact stage

Separate:
- association
- authentication
- authorization
- EAP/802.1X
- RADIUS/AAA reachability
- post-auth VLAN/role application

## Collect

- authentication successes/failures
- authorization successes/failures
- EAP method/reason/status where exposed
- RADIUS request/response/timeout/retransmission indicators
- RADIUS server health/reachability where available
- APs involved
- WLAN/security policy
- VLAN/role attributes where exposed
- affected vs healthy clients
- AP → RADIUS server distribution
- client → RADIUS server mapping for relevant authentication transactions
- connected/disconnected client population coverage for the investigation window

## Rules

- A generic deauthentication is not proof of authentication failure.
- A reason code must be interpreted using the actual event type.
- Successful authentication earlier in the day is useful negative evidence against a persistent credential failure, but does not rule out time-specific policy/backend problems.
- Multiple clients failing at the same time across APs increases the likelihood of shared AAA/WLAN causes.
- One client failing across multiple APs points toward client identity/supplicant/session behavior, but does not by itself prove client-side root cause.

## RADIUS correlation contract

For population-level RADIUS/server-selection analysis, also load `orchestrator/radius-analysis.md`. This is required when the investigation is trying to determine whether an AP, client population, or failure pattern is associated with a particular RADIUS server.


When authentication/authorization failure is a candidate cause, correlate the actual authentication event with the specific RADIUS/AAA evidence at the same incident timestamp. Where telemetry exposes a server identity, retain:

- RADIUS server identity
- request/response/timeout/retry status
- exact timestamp
- AP/WLAN/client context
- other clients using the same server/service during the same window
- whether healthy clients successfully authenticated through the same server/service

Do not call the RADIUS service the root cause merely because the client authentication failed. A shared RADIUS cause requires supporting server-side or cross-client evidence. If server-level telemetry is unavailable, say so explicitly.

## RCA discipline

Do not invent certificate, credential, ClearPass, RADIUS policy, PMKID, PMF, or 802.11r causes unless the MCP telemetry supports them.

## AP-specific authentication-path isolation

When one AP uses a particular RADIUS/NAC server or authentication path, do not equate that difference with a RADIUS-server root cause. Correlate:

`client → AP → RADIUS request → RADIUS server receipt → response (ACCEPT/REJECT/TIMEOUT) → AP receipt/completion → authorization → DHCP`

A successful authentication on the same AP/path proves the path can work but does not rule out an intermittent failure. Compare successful and failed transactions by timestamp and, where possible, compare another AP using the same server. If the server receives and accepts the request but the AP/client exchange still fails, shift investigation toward AP/EAPOL handling or the client exchange. If the server rejects, use the server-side reject reason; if it never receives the request, investigate the path before blaming NAC policy.

For 802.11r/FT cases, distinguish an authentication failure during a roam from an initial authentication failure. A client that successfully authenticates and receives DHCP on AP03 and then roams to AP04 requires separate analysis of the roam trigger and post-association behavior; do not label the roam itself as an authentication failure.

## Full-EAP versus 802.11r/FT entry-path analysis

When an AP has both successful and failed authentication/association attempts, explicitly determine whether the transaction used:

- full/new 802.1X/EAP authentication;
- 802.11r/FT reassociation;
- ordinary reassociation without FT; or
- an unknown path.

Use actual MCP fields such as `auth_type`, FT event types, capability fields, `time_since_assoc`, and timestamped EAP/authentication events when exposed.

A pattern such as:

`auth_type=eap` + long session gap → failure

versus

`auth_type=eap-11r` + short session gap → success

is a **correlation requiring validation**, not proof that 11r itself is faulty or that RADIUS is the mechanism. Test the pattern across multiple clients and compare cases where full EAP succeeds as well.

### Transaction-path test

For a suspected full-EAP problem, correlate:

`association → EAPOL/EAP → RADIUS request → RADIUS response → AP completion → authorization`

using exact timestamps where available. If the RADIUS server accepts the transaction but AP/client completion fails, the evidence shifts away from a server reject and toward the AP/client exchange; if the server never receives the request, investigate the path; if it rejects, use the actual reject evidence. Do not infer any of these states from a generic auth-failure event.

### Successful long-lived clients

Long-established AP clients using the same RADIUS server are important negative/control evidence. They show that the AP/RADIUS path can work under at least one connection state, but they do not prove that every entry path works. Compare their entry method, session age, FT state, EAP exchange and timestamps with failing/re-entry clients.

## Required differential for AP-specific authentication symptoms

When a suspect AP has both successful and failed entries, automatically build a differential matrix across: same client/same AP, same client/peer AP, healthy clients/suspect AP, and failed/re-entry clients/suspect AP. At minimum compare:

- `auth_type` (`eap`, `eap-11r`, or equivalent);
- previous AP and roam direction;
- association/reassociation/FT event sequence;
- PMF/SA Query evidence;
- RADIUS server identity and transaction outcome;
- EAP/authentication events and timestamps;
- RSSI/SNR and radio context;
- `time_since_assoc` or session-age fields;
- client/device/capability fields when exposed.

### Minimum-factor rule

The orchestrator must identify the smallest difference that is consistently reproduced across multiple independent attempts before calling it a differentiator. Do not treat `time_since_assoc` as causal merely because it differs between one success and one failure. Likewise, `auth_type=eap` versus `eap-11r` establishes an entry-path correlation; it does not prove that FT, PMK/R0/R1 state, or an AP-internal key mechanism is defective.

If full EAP fails on the suspect AP but succeeds for the same client on peer APs using the same WLAN/RADIUS path, classify this as strong AP-specific authentication-path evidence. Continue to separate that conclusion from the unobserved internal mechanism.



## Controlled AP replacement test

When authentication failures are investigated across an AP replacement/relocation, compare the same WLAN/client conditions before and after the intervention. If the replacement AP succeeds in the suspect AP's former location while the suspect AP fails after relocation, treat this as strong AP-specific authentication-path evidence. Do not label the replacement AP faulty because its installation generated expected restart/disconnect events.
