---
name: change-correlation
version: 1.3.4
description: Correlates configuration, software and infrastructure changes with the actual incident window.
---

# Change Correlation

## Search where available

- WLAN/SSID changes
- authentication/security/RADIUS changes
- AP configuration changes
- RF/channel/power/RRM changes
- switchport/VLAN changes
- DHCP/DNS changes
- firmware/software upgrades
- site/network changes
- relevant user/admin changes
- administrator/audit logs for manual AP reboot, maintenance, configuration, firmware, WLAN, RF, or security actions

## Correlation rule

For AP uptime/reboot observations, first determine whether an administrator/audit record explains the reboot as an intentional action.

A change is a candidate cause only when:
1. it occurred before or during the incident
2. it affects the dependency involved
3. the affected scope matches
4. the telemetry shows the symptom after the change

Temporal proximity alone is not proof.

## Output

For each relevant change:
- timestamp
- changed object
- change type
- relation to affected dependency
- scope match
- supporting evidence
- contradicting evidence
- confidence
