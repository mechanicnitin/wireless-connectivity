---
name: intent-router
version: 1.3.7
description: Classify the user's request before selecting troubleshooting orchestration. Preserves normal Juniper Mist MCP behavior for non-incident queries.
---

# Intent Router

## Purpose

Prevent the troubleshooting framework from hijacking ordinary Juniper Mist MCP questions.

## Step 1 — Classify the request

Choose exactly one primary intent:

### A. NORMAL MCP QUERY
Use when the user asks to retrieve, list, count, locate, inspect, show, describe, check status, or report information without asking for diagnosis.

Examples:
- list all APs at a site
- how many APs are online
- show clients on an SSID
- when does the Mist Edge subscription expire
- how many admin users are configured
- show WLANs at a site
- show AP events
- list switches
- what firmware is an AP running

**Action:** Use the Juniper Mist MCP normally. Return the requested information directly. Do not load the troubleshooting investigation engine.

### B. TROUBLESHOOTING / DIAGNOSTIC INVESTIGATION
Use when the user asks why, troubleshoot, investigate, diagnose, RCA, root cause, slowness, poor performance, high ping/latency, poor voice quality, jitter, packet loss, intermittent connectivity, cannot connect, cannot associate, cannot authenticate, no IP address, keeps disconnecting, roaming/walking dropouts, authentication problem, roaming problem, DHCP/DNS problem, AP problem, site wireless issue, unhappy clients, or equivalent diagnostic language.

**Action:** Load `investigation-engine.md`.

### C. HYBRID
Use when the request first asks for data and then asks for interpretation, for example:
- "List the APs at Site A and tell me which ones look unhealthy."
- "Show the client's events and explain why it keeps disconnecting."

**Action:** Complete the requested normal lookup first, then activate only the investigation modules required for the interpretation.

## Step 2 — Do not infer troubleshooting intent from identifiers

A client MAC, AP name, site name, SSID, VLAN, or event code does not by itself make a request a troubleshooting incident.

Example:
> "Show me details for client 38:18:68:b3:81:4d."

This is a NORMAL MCP QUERY unless the user asks for diagnosis.

## Step 3 — Troubleshooting depth

For troubleshooting intent, do not limit investigation to the first symptom named by the user.

Example:
> "Why is client X slow?"

Treat "slow" as the symptom. Investigate the end-to-end wireless dependency chain and cross-correlate RF, roaming, association, authentication, DHCP/IPv4, ARP/gateway, DNS, AP health, wired path, shared services, other clients, site behavior, SLEs, and relevant changes.

The user should not need to enumerate the failure domains. The symptom is only an entry point; the engine must determine which dependency actually failed first.

## Step 4 — Output mode

- NORMAL → direct factual answer in the format appropriate to the query.
- HYBRID → factual result first, then concise evidence-based analysis.
- TROUBLESHOOTING → use the investigation response structure.

Never emit the troubleshooting response template for a normal query.
