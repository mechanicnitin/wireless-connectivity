---
name: investigation-gap-closure
version: 1.3.5
description: Evidence sufficiency, contradiction handling, and closure rules for wireless investigations.
---

# Investigation Gap Closure

## Purpose

Prevent premature RCA when the current MCP evidence is incomplete, contradictory, or ambiguously attributed. This file is a closure contract, not a requirement to run every possible MCP query.

## Required closure checks

Before final RCA, verify:

- investigation entity and scope are clear
- investigation window and site-local timezone are established
- actual incident episode(s) are identified when possible
- important events have chronological before/after context
- event-to-AP/client attribution is verified
- relevant failure domains were attempted or explicitly unavailable
- affected and healthy control populations were compared where possible
- AP uptime/reboot evidence was interpreted with AP events and available admin/audit logs
- recent changes were checked when temporally relevant
- candidate causes have evidence for and evidence against
- IPv6/DHCPv6 is excluded in this IPv4-only environment unless explicitly requested

## Contradiction handling

If two MCP observations appear inconsistent:

1. verify timestamps and timezone
2. verify entity identity (AP name, AP ID, BSSID, client, WLAN)
3. verify whether the records refer to the same episode
4. check for state transitions between observations
5. check whether one record is a current-state snapshot and the other is historical telemetry
6. check available admin/audit/change logs when a reboot/configuration action could explain the difference
7. if unresolved, report the contradiction as a data gap rather than choosing the convenient record

## Evidence boundary

If the minimum available MCP evidence cannot distinguish the leading hypotheses, stop escalation at the evidence boundary. State:

- **RCA not yet confirmed**
- leading hypotheses
- evidence supporting each
- evidence against each
- exact missing telemetry/test
- what result would confirm or weaken each hypothesis

Do not manufacture certainty to complete the report.

## AP uptime rule

A lower AP uptime is an observation, not an AP-failure diagnosis. A reboot may be manual, configuration-driven, maintenance-related, power-related, software-related, or fault-related. Where relevant, correlate uptime/reboot timestamps with AP events and available administrator/audit/change logs before calling the reboot causal.

## Minimum-next-test rule

Prefer the smallest additional MCP query that can distinguish the top remaining hypotheses. Do not repeat broad queries whose evidence is already sufficient.

## AP-selection / authentication closure requirements

For an investigation where clients prefer a farther AP, do not close the case on RSSI comparison alone. Before RCA, establish as far as MCP permits:

- whether the client successfully authenticated and received IPv4/DHCP on the nearer AP
- whether the subsequent roam had an explicit trigger/reason
- whether 802.11k/v/r or AP steering evidence exists
- whether the nearer AP shows repeated authentication/association failures for the same or other clients
- whether those failures are AP-specific, client-specific, WLAN-specific, or shared-service-wide
- whether AP identity follows the symptom after any physical relocation/swap intervention
- whether the relevant RADIUS server actually received and responded to the failed transactions

If these cannot be established, state **RCA not yet confirmed** and name the exact missing telemetry.

## Entry-path evidence boundary

For AP-selection/authentication investigations, do not close the investigation until the following question has been answered as far as MCP permits:

> Do successful long-established AP sessions differ systematically from failed/new/re-entry AP sessions?

Where possible, compare the same client and then multiple clients across:
- previous AP
- association type
- `auth_type`
- 802.11r/FT
- PMF/security context
- session age / `time_since_assoc`
- RADIUS server and transaction outcome
- EAP/authentication events
- RSSI/radio
- client model/capability
- timestamps

If the pattern is present for only one client, classify it as client-level correlation. If it reproduces across multiple clients on the same AP, it becomes AP-scope evidence. If it reproduces across APs, reassess the hypothesis as WLAN/shared-service/client-population behavior.

Do not infer a causal mechanism merely because two fields differ. Require a discriminating test or explicitly report the mechanism as unresolved.
