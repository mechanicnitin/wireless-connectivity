---
name: client-investigation
version: 1.3.6
description: End-to-end client investigation baseline and entity state collection.
---

# Client Investigation

## Baseline

Collect what the MCP exposes:
- MAC / client identifier
- hostname
- OS/device type
- username/identity
- site/building/floor
- SSID/WLAN
- VLAN
- IPv4 address
- IPv6 status only as metadata; never use IPv6/DHCPv6 as evidence in this IPv4-only environment
- authentication method
- key management/encryption
- current AP
- historical APs during the incident window
- band/radio/channel/channel width
- RSSI/SNR
- PHY/tx/rx rates
- session/uptime if available

## Client state ladder

Determine the highest state actually supported by evidence:

```text
Seen → Associated → Authenticated → Authorized → IPv4 assigned → ARP/gateway reachable → DNS working → service connectivity
```

Do not infer a state merely because a downstream event exists.

## Timeline

For significant events, retain:
- timestamp
- event type
- reason/status code
- AP
- WLAN
- band
- relevant RF metrics
- preceding event
- following event

## Symptom handling

"Slow", "unstable", "intermittent", "drops", and "can't connect" are symptoms, not diagnoses. Branch into all relevant domains and identify which telemetry actually explains the symptom.

## Automatic deep-dive for named clients

A named-client troubleshooting request is a request for an investigation, not merely a current-client lookup. After baseline collection, automatically construct the most complete connection timeline MCP permits. Include:

- previous AP → suspect AP → next AP sequence;
- association/reassociation and deauth/disassoc events;
- authentication/802.1X/EAP and authorization events;
- RADIUS server identity/outcome when exposed;
- 802.11r/FT and PMF/SA Query events;
- RSSI/SNR, band/radio/channel and relevant RF indicators;
- exact timestamps and local-time presentation;
- successful versus failed attempts;
- long-established successful sessions on the suspect AP; and
- the same client's behavior on peer APs.

Do not require a follow-up “magic prompt” to obtain these fields when they are relevant to the symptom. Reuse already-collected evidence rather than issuing redundant queries.

### Entry-path differential

When the symptom is AP-specific association/authentication failure, explicitly partition entries into full/new EAP, FT/11r, ordinary reassociation, and pre-EAP association failures. Compare success and failure within the same client and then across clients. A field difference is not causal merely because it is present in one success and one failure.

