# Juniper Mist AI v1.3.8 — Cross-Symptom Correlation / PCAP RCA Hardened

Evidence-driven Juniper Mist MCP assistance with a modular wireless investigation orchestrator.

## What changed in v1.3.5 / correlation hardening

- Added an intent router so normal MCP lookups remain normal MCP lookups.
- Added a modular investigation engine for complete wireless troubleshooting.
- Added incident-window and chronological event-correlation logic.
- Added dedicated RF, authentication, AP, cross-client, site, IPv4 network-path, change, and RCA modules.
- Added a client-performance playbook for slowness/poor-performance cases.
- Added a Marvis-inspired methodology reference based on observable Juniper documentation, without depending on Marvis VNA output.
- Explicitly excludes IPv6/DHCPv6 from RCA for this IPv4-only environment unless requested.
- Preserves the existing knowledge, skills and focused playbooks as supporting layers.
- Revalidated broad-first investigation behavior so focused playbooks cannot bypass cross-domain correlation.
- Clarified exact playbook handoff names and strengthened the legacy parent skill so it cannot revert to a single-domain/rigid command order.
- Added a shared investigation-context contract so every correlation uses one stable entity/time/causal window.
- Added an investigation-gap-closure contract with a mandatory evidence-sufficiency/closure gate.
- Added contradiction/attribution checks and AP uptime-versus-manual-reboot safeguards.
- Added site-local time and resolved AP-name presentation rules for roaming/timelines.
- Strengthened RADIUS server/timestamp/cross-client correlation and affected-vs-healthy controls.
- Added a telemetry-collection contract that captures the master-prompt evidence requirements without duplicating a giant prompt across modules.
- Added an optional second-opinion contract for Marvis VNA or another trusted diagnostic source; MCP remains primary.
- Hardened the dependency model so RF/AP health/wired/SLE/scope are cross-cutting evidence domains rather than falsely sequential failure stages.
- Hardened performance analysis so reconnect latency/contributors are not mislabeled as proven sustained application slowness.

## Drop-in hierarchy

```text
Juniper-Mist-AI/
├── orchestrator.md                 # compatibility/bootstrap entry point
├── orchestrator/
│   ├── intent-router.md
│   ├── investigation-context.md
│   ├── telemetry-collection-contract.md
│   ├── investigation-engine.md
│   ├── client-investigation.md
│   ├── incident-window.md
│   ├── event-correlation.md
│   ├── rf-analysis.md
│   ├── authentication-analysis.md
│   ├── ap-correlation.md
│   ├── cross-client-analysis.md
│   ├── site-correlation.md
│   ├── network-path-analysis.md
│   ├── change-correlation.md
│   ├── rca-and-confidence.md
│   ├── investigation-gap-closure.md
│   └── second-opinion.md
├── knowledge/
├── skills/
├── playbooks/
│   └── voice-quality.md              # focused voice/meeting quality correlation
├── response/
└── memory/
```

## Critical behavior

A query such as "list all APs at Amsterdam" or "when does the Mist Edge subscription expire" must stay on the normal MCP path. The troubleshooting framework activates only for diagnostic intent.

A query such as "why is client X slow?" activates the full evidence-driven wireless investigation automatically; the user does not need to enumerate RF/DHCP/DNS/authentication/AP checks.

## Source-of-truth hierarchy

1. Live Juniper Mist MCP telemetry
2. Knowledge/design
3. Skills/methodology
4. Playbooks
5. Response formatting
6. Memory/context

## Safety

Diagnostic by default. No automatic configuration changes. Diagnose → Explain → Recommend.

## v1.3.5 design note

The package does not copy Marvis VNA's internal reasoning. It adopts only useful observable investigation practices demonstrated by Juniper documentation and the supplied test results: stable time-window correlation, affected/healthy comparison, AP/WLAN/site concentration, SLE/event use as evidence, and broad-to-focused investigation. The RCA remains evidence-gated and MCP-first.

## v1.3.5 additions
- Added `orchestrator/controlled-intervention-analysis.md` for AP reboot/swap/relocation and other controlled troubleshooting interventions.
- Strengthened AP identity vs physical-location isolation, authentication-path attribution, and roam causality guardrails.


## v1.3.6 targeted RCA hardening
- Preserves v1.3.5 as the baseline; no unrelated knowledge, skills, memory, response, or normal-query flows were redesigned.
- Named-client troubleshooting now automatically builds a deep connection timeline before narrowing the investigation: AP sequence, association/authentication, 802.11r/FT, PMF, RADIUS, RF and timestamps where exposed.
- Added explicit same-client/same-AP and peer-AP controls for full-EAP versus FT/11r entry-path comparisons.
- Added a hard minimum-differentiator rule: correlated fields such as `time_since_assoc` cannot be promoted to mechanism without replication/discrimination.
- Strengthened event attribution using timestamp + client + AP/BSSID + event type and neighboring timeline context before assigning causality to an AP.
- Separates roam decision, roam execution, destination entry, and established-session behavior. A successful roam does not explain why the client left.
- Treats AP replacement/relocation as a controlled intervention: compare AP identity versus physical location and preserve pre/post constants.
- Strengthened RADIUS population analysis for AP→server and client→server visibility, including connected/disconnected population in the default investigation window when MCP permits.
- Strengthened firmware/model/hardware/uptime/reboot parity checks without treating short uptime or a reboot as causal by itself.
- Keeps the RCA boundary explicit: strong AP-specific evidence can justify TAC escalation without claiming an unobserved internal AP mechanism.


## v1.3.7 cross-symptom and PCAP extension
- Preserves v1.3.6 as the baseline; no unrelated working modules were redesigned.
- Extends the broad-first investigation contract across common wireless symptoms: slow Wi-Fi, inability to connect, roaming/walking dropouts, repeated disconnects, poor voice quality, high ping/latency, association failure, authentication failure and missing IPv4 address.
- Adds symptom normalization so user wording selects candidate evidence domains without becoming a causal conclusion.
- Adds `orchestrator/pcap-analysis.md` for controlled use of MCP-provided `pcap_urls` or equivalent packet-capture references.
- Adds PCAP attribution, safe retrieval, packet-fact extraction, timestamp correlation, peer/control comparison and confidence rules.
- Adds a focused `voice-quality.md` playbook for latency/jitter/loss/roaming/application correlation.
- Extends association, authentication, performance and disconnection investigations with PCAP escalation when available.
- Keeps the MCP-first model: if PCAP retrieval or parsing is unavailable, the investigation continues and reports the data gap.
- Keeps RCA evidence-gated: packet evidence can strengthen or weaken a hypothesis but cannot prove an internal AP/RADIUS/client/application mechanism unless the evidence directly exposes it.


## v1.3.7 controlled-test / evidence-attribution hardening
- Treats deliberate AP replacement, relocation, reboot and maintenance as explicit experimental context.
- Prevents expected test-generated restart/disconnect/configuration events from increasing the replacement AP's fault confidence merely because they overlap the incident window.
- Gives controlled before/after identity-versus-location evidence precedence over simple temporal coincidence.
- Adds explicit distinction between observed events, incident-relevant events and causal evidence.
- Records PCAP retrieval state so a `pcap_url`/reference is never represented as packet analysis unless bytes were actually retrieved and parsed.
- Allows portal/session-protected or signed capture references to remain a data gap without exposing bearer tokens.


## v1.3.8 direct PCAP retrieval extension

- Adds `orchestrator/pcap-download.md` and `tools-download-pcap.py` for direct retrieval of the exact signed PCAP reference returned by MCP.
- Accepts generic binary `application/octet-stream` responses and validates PCAP/PCAPNG magic bytes before analysis.
- Separates URL discovery, retrieval, validation and parsing states; a URL is never treated as packet evidence merely because it exists.
- Enforces HTTPS, bounded download size/timeouts, optional host allowlisting, temporary storage and credential redaction.
- Preserves the MCP-first and evidence-attribution model and applies across all supported wireless symptom families.
- A network egress/allowlist failure is recorded as an environment limitation, not as evidence of an AP/client/network fault.


## v1.3.9 cross-symptom investigation / PCAP automation hardening
- Preserves v1.3.8 as the baseline and makes only targeted orchestrator, playbook and validation changes.
- PCAP discovery is now an automatic investigation step whenever a relevant MCP event exposes `pcap_url`/`pcap_urls`; the model must attempt retrieval without waiting for a second user prompt.
- Adds explicit capture ranking and bounded multi-capture sampling so the engine selects the highest-value incident PCAPs first and analyzes them against the exact event/client/AP/timestamp.
- Separates `reference discovered` from `retrieval attempted`, `bytes retrieved`, `capture parsed`, and `packet facts extracted`; a blocked URL is reported as a tooling/environment limitation and never as network evidence.
- Adds a no-user-prompt fallback: if direct retrieval is blocked, the engine continues MCP correlation and states exactly what packet evidence is missing; if a PCAP is manually attached later, it must be ingested as the same incident evidence layer without changing the RCA rules.
- Strengthens controlled-intervention precedence so replacement/reconfiguration/reboot-generated events cannot make the replacement AP look faulty merely because the event overlaps the test.
- Adds explicit AP-identity-versus-location experiment scoring and a rule that a post-swap recurrence on the moved suspect AP plus success of the replacement in the old location outranks simple reboot/disconnect coincidence.
- Adds regression checks for the AP03→AP07 replacement pattern and for the earlier false-AP07 interpretation.
- Applies the same PCAP and intervention logic to slow Wi-Fi, inability to connect, roaming/walking dropouts, repeated disconnects, voice quality, high ping/latency, association failure, authentication failure and missing IPv4 address.
