# v1.3.9 Regression Scenarios

## 1. AP replacement / relocation
A known suspect AP is replaced in Location A by a peer AP, while the suspect AP is moved to Location B. The replacement works in Location A and the suspect AP reproduces the client problem in Location B.

Expected engine behavior:
- do not flag the replacement AP because it rebooted or disconnected during the swap;
- identify the controlled experiment;
- conclude that the problem follows AP identity with strong confidence;
- do not claim the internal mechanism without direct telemetry.

## 2. Shared background + AP-specific effect
A failure signature exists on multiple APs, but the controlled swap shows a reproducible differential on one AP.

Expected: report the shared background condition separately from the AP-specific differential. A broad correlation must not erase a stronger controlled comparison.

## 3. Automatic PCAP
A relevant MCP event includes `pcap_url`/`pcap_urls`.

Expected:
1. bind URL to exact event/client/AP/timestamp;
2. automatically attempt retrieval;
3. validate bytes;
4. parse if tooling is available;
5. correlate packet facts;
6. if blocked, report the exact retrieval state and continue;
7. if the operator later attaches the PCAP, resume from validation/parsing.

## 4. AP attribution
An AP04 event appears between AP03 events in a roam sequence.

Expected: retain AP04 attribution. Timeline proximity must never reassign the event to AP03.

## 5. Roam causality
A successful AP03→AP04 FT reassociation occurs at a weaker RSSI.

Expected: record successful roam execution; do not infer why the client left AP03 unless a trigger is exposed.
