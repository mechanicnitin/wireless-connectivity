---
name: response-structure
description: Dynamic response format for Juniper Mist MCP queries, with a detailed evidence structure for troubleshooting investigations.
---

# Wireless Troubleshooting Response Structure

# 0. Response Mode Gate

Before using this troubleshooting structure, follow `orchestrator/intent-router.md`.

- **NORMAL MCP QUERY:** answer directly in the format appropriate to the requested lookup. Do not add incident phases, RCA, failure-point analysis, or troubleshooting boilerplate unless requested.
- **HYBRID:** answer the requested data lookup, then provide only the diagnostic analysis requested.
- **TROUBLESHOOTING:** use the full structure below.

This gate prevents ordinary queries such as AP inventory, subscription status, admin-user counts, WLAN listings, or site details from being turned into troubleshooting reports.


## 1. Purpose

Every completed wireless troubleshooting investigation should use this structure.

The response must be:
- Evidence-based
- Concise but technically useful
- Explicit about uncertainty
- Traceable to live MCP data and documented topology
- Suitable for later conversion into incident reports, Jira tickets, Confluence pages, or daily operational summaries

Do not produce an unstructured narrative when this response format applies.

---

# 2. Response

## Issue Summary

Briefly describe:
- What the user reported
- What was investigated
- Current status, if known

Example:

> Client is unable to maintain a wireless connection on the Branch-01 site. Investigation covered client state, AP health, association, RF indicators and the AP's wired path.

---

## Scope / Impact

State:
- Site
- Client(s)
- AP(s)
- SSID
- Area/VLAN if known
- Number/scope of affected clients
- Whether the issue is isolated or widespread

Classify scope where possible:

- Single client
- Multiple clients on one AP
- Multiple APs / local area
- Site-wide
- Multi-site/shared dependency

---

## RADIUS / AAA Distribution

Include this section when authentication/RADIUS analysis was material. Show only telemetry actually available:
- configured RADIUS pool, if current MCP exposes it
- observed AP → RADIUS server distribution
- observed client → RADIUS server mapping
- connected/disconnected population coverage for the investigation window
- success/failure/timeout/retry counts by server when comparable denominators exist
- affected vs healthy comparison by server/AP
- NAS-Identifier limitations when a shared AP subnet prevents unique AP attribution
- whether the evidence points to server-specific, AP-specific, client-specific, time-specific, or undetermined behavior

Use AP names rather than BSSIDs when available and site-local timestamps when the site timezone is known. Do not infer actual server selection from a configured server pool or randomization setting alone.

## Client & AP Details

Include relevant identifiers:

- Client MAC / identifier
- Client hostname/user if available
- AP name
- AP MAC if available
- SSID
- Site
- VLAN/subnet if available

Do not expose unnecessary sensitive information.

---

## Investigation Context

State the shared context used for causal correlation:
- timezone
- investigation window
- actual incident episode(s)
- causal correlation window
- client/AP/WLAN/site scope

Do not silently mix timestamps or scopes from separate investigations.

---

## Investigation Performed

List the checks that were actually performed.

Example:

1. Client association state
2. Authentication state
3. AP health and availability
4. AP SLEs/alarms/alerts
5. AP-to-switch mapping
6. Switchport operational state
7. PoE
8. LLDP
9. MAC learning
10. ARP
11. DHCP
12. DNS
13. RF metrics
14. Recent changes

Only list checks that were actually attempted.

---

## Evidence Found

Separate evidence into categories.

### Observed — Live MCP / telemetry

Information directly returned by MCP or another trusted live data source.

Example:

> AP `AP-01` is online and reporting normally.

### Documented — Knowledge

Information obtained from static `knowledge/` files.

Example:

> Site documentation indicates AP-01 should connect to SW-01 port Gi1/0/24.

### Inferred — Analysis

Conclusions derived by correlating observed and documented evidence.

Example:

> Because multiple clients on the same AP are affected while neighboring APs remain healthy, the issue is more likely localized to the AP or its wired path.

### Unknown — Data unavailable

Information that could not be verified.

Example:

> Current switchport PoE state could not be confirmed because the required live switch telemetry was unavailable through MCP.

Never present an inference as observed telemetry.

---

# 3. Investigation Timeline

When timestamps are available, present important events chronologically.

Presentation rules:
- Use site-local timezone for the affected site when known.
- Prefer AP names over BSSIDs when historical mapping is available.
- If only BSSID or UTC is available, show it explicitly and state the limitation.
- Do not infer historical AP identity from the client's current AP.
- For AP uptime/reboot events, do not label the AP faulty without correlating AP events and available admin/audit/change logs.

Example:

```text
10:03 — Client associated
10:03 — Authentication succeeded
10:04 — Client received IP
10:12 — Client disconnected
10:12 — Association retry failed
10:14 — AP alert generated
```

If timestamps are unavailable, say so.

Use the user's requested time window when provided. Otherwise state the actual window used by the investigation.

---

# 4. Failure Point

Identify the first confirmed failed stage.

Use the dependency chain:

```text
Client
  ↓
AP
  ↓
Association
  ↓
Authentication
  ↓
DHCP / IP
  ↓
DNS
  ↓
Gateway / network
  ↓
Application
```

Examples:

> **First confirmed failure: Authentication**

or:

> **First confirmed failure: DHCP / IP assignment**

If no failure is confirmed:

> **First confirmed failure: Not established**

Do not force a failure point.

---

# 5. Failure-Domain Correlation

For material candidate domains, summarize:

| Domain | Evidence for | Evidence against | Temporal correlation | Scope | Status | Confidence |
|---|---|---|---|---|---|---|
| ... | ... | ... | ... | ... | ... | ... |

Keep observed telemetry separate from inference.

---

# 6. Root Cause

If the evidence sufficiency/closure gate has not been passed, explicitly state:

> **RCA not yet confirmed.**

Then list the leading hypotheses, evidence for and against each, the exact missing telemetry/test, and what result would confirm or weaken the hypothesis. Do not fill the gap with a plausible narrative.

Only provide a root cause when the evidence supports it.

Use:

### Confirmed Root Cause

When direct evidence establishes the cause.

### Most Likely Root Cause

When multiple observations strongly support the conclusion but direct proof is unavailable.

### Root Cause Not Confirmed

When evidence is insufficient.

Do not convert correlation into certainty.

---

# 7. Recommended Action

Give the next operational action based on the evidence.

Actions should be:
- Specific
- Safe
- Relevant to the confirmed failure
- Appropriate to the user's operational role

Prefer investigation/remediation recommendations over destructive actions.

Do not make configuration changes automatically unless the user explicitly authorizes an automation workflow and the required control mechanisms exist.

---

# 8. Confidence

Use one of:

### High
Direct telemetry confirms the failure and strongly supports the RCA.

### Medium
Multiple pieces of evidence support the conclusion, but one or more dependencies could not be directly verified.

### Low
The evidence is incomplete or multiple explanations remain plausible.

Always provide a short reason.

---

# 9. Data Gaps

Explicitly list information that was needed but unavailable.

Examples:

- Switchport operational state unavailable
- PoE telemetry unavailable
- RADIUS response unavailable
- DHCP event details unavailable
- Current ARP table unavailable
- Recent configuration change history unavailable

Data gaps must not be silently filled with assumptions.

---

# 10. Next Steps

State the next troubleshooting action.

Examples:

- Invoke `authentication-failure.md`
- Invoke `dhcp-failure.md`
- Investigate AP switchport
- Compare affected and healthy clients
- Collect missing switch telemetry
- Escalate to the relevant infrastructure/service owner

If the issue is resolved, state the validation that should confirm recovery.

---

# 11. Playbook Traceability

When a playbook was used, optionally include:

```text
Skill:
wbc-noc-ai-wireless-client-troubleshooting.md

Playbook:
playbooks/association-failure.md

Knowledge:
knowledge/site-design/<relevant-site>.md
```

This is useful for debugging the AI workflow and auditing why a conclusion was reached.

---

# 12. Response Quality Rules

The response must:

1. Lead with the actual issue.
2. Avoid unnecessary generic networking explanations.
3. Separate facts from inference.
4. State missing data.
5. Never fabricate MCP results.
6. Never claim a command was executed unless it actually was.
7. Never claim a configuration change was made unless it actually was.
8. Use timestamps when available.
9. Identify scope before declaring a site-wide issue.
10. Prefer the first confirmed failure over downstream symptoms.
11. Reference site knowledge when topology/design assumptions matter.
12. Keep remediation separate from diagnosis.

---

# 13. Compact Executive Summary

When the user asks for a short answer, preserve the same logic but compress the output to:

```text
Issue:
Scope:
First confirmed failure:
Evidence:
Likely root cause:
Recommended action:
Confidence:
Data gaps:
```

Do not omit uncertainty simply because the response is short.

## Entry-path / Roaming Analysis Requirements

For investigations involving AP preference, roaming, or AP-specific authentication, include a concise distinction between:

1. **Roam decision:** why the client appears to have initiated the roam — only state a cause when supported by telemetry.
2. **Roam execution:** whether reassociation/11r/FT succeeded or failed.
3. **New/re-entry attempt:** whether a subsequent attempt to enter the AP used full EAP, FT, or another path and its outcome.
4. **Established session:** whether long-lived clients remain healthy on the AP.

When evidence exists, show the minimum successful-versus-failed differentiators, including `auth_type`, FT status, session age, previous AP, RADIUS server, EAP/authentication events, PMF/security context, RSSI, and timestamps.

Use language such as **"strong correlation"** or **"hypothesis"** unless the mechanism has been independently validated. Never label a successful roam at weaker RSSI as "RF-driven" without supporting evidence.
