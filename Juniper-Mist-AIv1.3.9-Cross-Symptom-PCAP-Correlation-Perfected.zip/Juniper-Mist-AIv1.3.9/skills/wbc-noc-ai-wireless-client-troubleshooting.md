---
name: wireless-client-troubleshooting
description: End-to-end Juniper Mist wireless client troubleshooting with automatic cross-domain correlation, scope analysis, incident-window detection, RF/authentication/network-path/AP correlation, and evidence-driven RCA.
---

# Wireless Client Troubleshooting Skill

# v1.3 Orchestration Contract

For diagnostic requests, this skill is invoked through `orchestrator/investigation-engine.md`. Do not restrict investigation to the symptom named by the user. The orchestrator owns incident-window detection and cross-domain correlation; this skill supplies the detailed client troubleshooting procedure.

Use `orchestrator/investigation-context.md`, `telemetry-collection-contract.md`, `client-investigation.md`, `incident-window.md`, `event-correlation.md`, `rf-analysis.md`, `authentication-analysis.md`, `ap-correlation.md`, `cross-client-analysis.md`, `site-correlation.md`, `network-path-analysis.md`, `change-correlation.md`, and `rca-and-confidence.md` as applicable.

For slowness/poor performance, also use `playbooks/client-performance.md`.

IPv6/DHCPv6 is out of scope for this IPv4-only environment unless explicitly requested.


## 1. Purpose

Use this skill whenever a user reports or asks to investigate a wireless client connectivity problem.

Examples:

- Client cannot connect to Wi-Fi
- Client keeps disconnecting
- Client cannot authenticate
- Client is connected but has no IP address
- Client has an IP but cannot reach services
- Client has poor wireless performance
- Multiple clients are affected in an area
- A client appears to have a problem related to its AP or the AP's wired uplink

The objective is to identify the **first failing dependency**, collect evidence from live MCP data, correlate it with the site's static knowledge, and produce an evidence-based diagnosis.

Do not invent telemetry that MCP did not return.

---

# 2. Required Context

Before investigating, identify as much of the following as possible:

- Client identifier (MAC, hostname, username, or other available identifier)
- Site
- AP
- SSID/WLAN
- Approximate incident time, if supplied
- User-reported symptom
- Whether the problem is isolated or affects multiple clients

If the user does not provide a time, use the current time and an appropriate recent window based on the MCP capabilities. State the time window used in the response.

If the site is known, consult the relevant `knowledge/` site and topology information before making topology-dependent conclusions.

---

# 3. Investigation Model

Use a **broad-first, dependency-aware** investigation rather than a symptom-driven single-domain workflow.

### Layer 1 — Broad baseline

For every troubleshooting request, attempt to collect and correlate:

```text
Client identity/state
Incident window + event timeline
AP(s) involved + AP health
Association / reassociation / deauthentication
Authentication / authorization / 802.1X / RADIUS
RF / roaming / radio conditions
IPv4 / DHCP / ARP / gateway
DNS / network connectivity
AP wired path / PoE / switchport where exposed
Other-client / healthy-control comparison
WLAN / site / SLE / shared-service behavior
Recent changes
```

### Layer 2 — Dependency-aware deep dive

Use the observed timeline to identify the **earliest confirmed broken dependency** and then load the focused playbook(s) needed to distinguish the remaining hypotheses.

The dependency chain is:

```text
Client state
  ↓
AP association
  ↓
Authentication / 802.1X
  ↓
Authorization / AAA result
  ↓
VLAN / role
  ↓
IPv4 / DHCP
  ↓
ARP / gateway
  ↓
DNS
  ↓
Network / WAN
  ↓
Application / service connectivity
```

RF/radio quality, AP health, wired path, scope, SLEs and shared services are cross-cutting evidence domains. They must be correlated with the actual incident timestamps rather than treated as sequential stages.

A downstream failure does not automatically explain an upstream symptom, and a clear failure in one domain does not exempt the investigation from checking the other relevant domains.

The sequence above is a reasoning model, not a command order. Avoid redundant queries when the required evidence is already available.

---

# 4. Step A — Identify the Client

Collect:

- Client identity
- Client MAC address
- Hostname, username, or device information if available
- Current/last-seen AP
- SSID
- VLAN/network segment if available
- Client state
- First/last seen information
- Recent connection/disconnection events
- Relevant SLEs
- Relevant alarms/alerts

Determine whether the client is:

- Not seen
- Seen but not associated
- Associated
- Authenticated
- Connected with an IP
- Connected but experiencing service/connectivity problems

---

# 5. Step B — Identify and Check the AP

Once the AP is identified, check:

## AP operational state

- AP online/offline
- Last seen
- Uptime if available
- Reboots
- Connectivity state
- Management/cloud connectivity

## AP health

Check relevant:

- SLEs
- Alarms
- Alerts
- Errors
- Resource/health indicators
- Recent changes

## AP scope

Determine:

- Is only this AP affected?
- Are nearby APs affected?
- Are multiple APs in the same site affected?

Do not immediately conclude that an AP is the root cause because one client is having trouble.

---

# 6. Step C — Trace AP to Connected Switch and Port

When the required information is available through MCP or the connected network data source, identify:

- AP's connected switch
- Switch hostname/identifier
- Switchport/interface
- AP MAC address
- Expected access/trunk behavior
- Relevant VLAN(s)

Then validate the AP's wired path.

This is a mandatory branch of the investigation for issues where the AP may have a wired connectivity problem.

---

# 7. Step D — Validate the AP Switchport

Check as many of the following as the available MCP/network data supports:

## Port operational state

- Interface administratively up/down
- Interface operational up/down
- Link state
- Link uptime / recent flaps
- Speed
- Duplex

## PoE

Check:

- PoE enabled/disabled
- PoE operational state
- Power being delivered
- Power budget/availability, if available
- PoE errors/faults
- Recent PoE events

## LLDP

Check:

- LLDP neighbor present
- Neighbor identity
- Neighbor port
- Expected AP identity/model
- Whether the observed neighbor matches the documented topology

If LLDP identifies a different device than expected, flag the topology mismatch rather than assuming the AP is connected correctly.

## Interface health

Check where available:

- Input errors
- Output errors
- CRC errors
- Drops
- Link flaps
- Discards
- Interface utilization

## VLAN / configuration

Validate:

- Expected VLAN configuration
- Native VLAN, where relevant
- Allowed VLANs, where relevant
- AP management VLAN
- WLAN/client VLAN relationship
- Configuration consistency with the site's LLD

---

# 8. Step E — Validate Layer-2 Learning

Where supported by the available MCP/network data, check:

## MAC learning

Determine:

- Is the AP MAC learned on the expected switchport?
- Is the client MAC learned?
- On which switchport/VLAN is the client MAC learned?
- Is the MAC moving/flapping between ports?
- Is the expected VLAN present?

A missing or unexpected MAC-learning result should be reported explicitly.

## ARP learning

For clients that should have an IP address, check:

- Is an ARP entry present?
- Is the client IP mapped to the expected MAC?
- Is the ARP entry on the expected gateway/device?
- Is the ARP state normal or stale/incomplete, if the data source exposes this?

Do not claim that ARP should exist for a client that has not yet completed DHCP/IP assignment.

---

# 9. Step F — Association

Determine whether the client successfully associates to the AP.

Check, where available:

- Association success/failure
- Association attempts
- Disconnect events
- Disconnect reason
- Reassociation/roaming behavior
- Time of failures
- AP involved
- Client signal/RF information

If association fails, investigate the association/RF/client/AP path before moving to authentication.

If association is successful, continue to authentication.

---

# 10. Step G — Authentication

Determine whether authentication succeeds.

Check:

- Authentication success/failure
- Failure reason
- RADIUS/AAA interaction
- Authentication timeout/reject/no-response indicators
- Relevant SLEs
- Authentication events
- Scope of affected clients

If multiple clients fail authentication around the same time, investigate the shared authentication dependency rather than treating each client independently.

If authentication succeeds, continue to DHCP/IP validation.

---

# 11. Step H — DHCP / IP Address

Determine whether the client receives a valid IP configuration.

Check:

- DHCP success/failure
- Client IP address
- VLAN/subnet
- DHCP-related SLEs/events
- Gateway
- Lease information where available
- Whether other clients on the same VLAN are also affected

If authentication succeeds but DHCP fails, classify the problem as a DHCP/IP-path problem unless evidence indicates another root cause.

---

# 12. Step I — DNS

Only investigate DNS after establishing that the client has usable IP connectivity.

Check:

- DNS server configuration if available
- DNS reachability
- Name-resolution failures
- Relevant client/service symptoms
- Whether the issue affects one client or many

Distinguish DNS failure from general network connectivity failure.

---

# 13. Step J — Gateway / Network Connectivity

Check:

- Default gateway
- Gateway reachability
- Client-to-gateway connectivity
- Relevant routing/VRF context
- WAN/SD-WAN dependency where applicable
- Site-wide connectivity indicators

If the client cannot reach its gateway, do not jump to application-level troubleshooting.

---

# 14. Step K — RF / Wireless Quality

When the symptom indicates RF or performance degradation, examine relevant Mist telemetry such as:

- RSSI
- SNR
- Channel
- Channel utilization
- Retry/retransmission indicators
- PHY/rate information
- Roaming behavior
- Neighboring AP context
- Relevant SLEs
- RF-related alarms/alerts

Use the site's wireless design knowledge when interpreting RF behavior.

Do not declare an RF issue solely from a single weak metric; correlate multiple indicators and the client symptom.

---

# 15. Step L — Recent Changes and Events

For the relevant incident window, check:

- Recent configuration changes
- AP changes
- WLAN/SSID changes
- Switch changes
- Authentication changes
- Network changes
- Relevant alarms
- Relevant alerts
- Reboots
- Interface flaps
- PoE events

Correlate timestamps whenever possible.

---

# 16. Step M — Determine Scope

Classify the impact:

### Single client

Investigate:

- Client
- AP
- RF
- Association
- Authentication
- DHCP
- DNS

### Multiple clients on one AP

Prioritize:

- AP health
- AP wired uplink
- Switchport
- PoE
- LLDP
- MAC learning
- RF
- Authentication

### Multiple APs in the same area

Prioritize:

- Access switch
- Uplinks
- VLANs
- Shared services
- RF/environment
- Authentication/DHCP

### Many clients across a site

Prioritize:

- Site-level infrastructure
- Shared authentication
- DHCP
- DNS
- WAN
- Core/distribution
- Site-wide changes

### Multiple sites

Investigate shared dependencies:

- Authentication/AAA
- DHCP/DNS
- WAN/SD-WAN
- Central services
- Common configuration changes

This is an investigation heuristic. Confirm the conclusion using live MCP evidence.

---

# 17. Evidence Rules

The AI must distinguish between:

### Observed

Directly returned by MCP or another trusted live data source.

### Documented

Found in the static `knowledge/` files.

### Inferred

A conclusion derived from multiple observations.

### Unknown

Information that was not available.

Never present an inference as direct telemetry.

Example:

Bad:

> "The switchport is down."

if MCP never returned switchport state.

Good:

> "MCP did not return switchport operational state, so the AP's wired link status could not be confirmed."

---

# 18. Escalation to Playbooks

This skill identifies the problem domain.

Once a specific failure is identified, hand off to the appropriate playbook.

Examples:

```text
Association failure
    → `association-failure.md` playbook

Authentication failure
    → `authentication-failure.md` playbook

DHCP failure
    → `dhcp-failure.md` playbook

DNS failure
    → `dns-failure.md` playbook

AP down
    → `ap-down.md` playbook

AP switchport / PoE issue
    → `ap-switchport.md` playbook

RF degradation
    → `rf-performance.md` playbook
```

Do not duplicate the complete playbook inside this skill.

---

# 19. Knowledge Usage

Use the static knowledge base to answer questions such as:

- Which switch should this AP connect to?
- What is the expected VLAN?
- What is the expected AP deployment?
- What is the expected authentication path?
- What is the site's network topology?
- What are the known service dependencies?

Use MCP/live telemetry to answer:

- Is the AP currently up?
- Is the switchport currently up?
- Is PoE currently working?
- Is LLDP currently showing the expected neighbor?
- Is the MAC currently learned?
- Is ARP currently present?
- Is the client currently associated/authenticated?
- Are current alarms/SLEs/events present?

---

# 20. Output Requirements

The final response should be structured as:

## Issue Summary

Brief description of the reported problem.

## Scope

Identify:

- Client(s)
- AP(s)
- Site
- SSID
- Scope of impact

## Investigation

Summarize the checks performed in logical order.

## Evidence

List important observed data.

## Failure Point

Identify the first confirmed failed dependency.

## Root Cause

State the most likely root cause only when supported by evidence.

## Recommended Action

Give the next operational action.

## Confidence

Use:

- High
- Medium
- Low

Explain why.

## Data Gaps

Explicitly list checks that could not be performed because the required MCP/network data was unavailable.

## Escalation

If the issue cannot be resolved with available evidence, identify what team/domain should investigate next and what evidence should be collected.
