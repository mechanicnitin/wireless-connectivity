# Wireless Scope Analysis Skill

## Objective
Determine whether an issue is client-specific, AP-specific, WLAN-specific, area/site-wide, multi-site, or shared-service related.

## Required comparisons

Correlate affected clients by:
- AP
- WLAN/SSID
- band/radio/channel
- site/area
- VLAN
- authentication method
- shared service

Compare against healthy clients in the same time window when possible.

## Scope classes

1. CLIENT-SPECIFIC
2. AP-SPECIFIC
3. WLAN-SPECIFIC
4. AREA/MULTI-AP
5. SITE-WIDE
6. MULTI-SITE/SHARED-SERVICE
7. UPSTREAM/INFRASTRUCTURE
8. UNDETERMINED

Scope is a classification, not proof of root cause.
