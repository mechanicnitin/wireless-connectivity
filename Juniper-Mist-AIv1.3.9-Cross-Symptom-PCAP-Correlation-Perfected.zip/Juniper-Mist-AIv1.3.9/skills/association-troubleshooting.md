# Association Troubleshooting Skill

## Objective
Diagnose client association and disconnection problems.

## Checks
- Client and AP identity
- Association success/failure
- Connection/disconnection events and timestamps
- Disconnect reason
- Reassociation/roaming
- RSSI/SNR
- Channel/utilization/retry indicators
- AP health and recent changes
- Other clients on the same AP

Do not infer an RF root cause from one metric alone.
