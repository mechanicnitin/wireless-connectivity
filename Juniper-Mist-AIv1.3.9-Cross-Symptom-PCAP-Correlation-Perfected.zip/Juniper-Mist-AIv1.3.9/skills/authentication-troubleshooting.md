# Authentication Troubleshooting Skill

## Objective
Diagnose wireless authentication failures and RADIUS/AAA symptoms.

## Checks
1. Confirm association.
2. Check authentication state and events.
3. Check failure reason.
4. Check RADIUS/AAA interaction.
5. Distinguish reject, timeout, no-response and policy symptoms.
6. Check affected-client scope.
7. Check RADIUS/AAA alarms, events and recent changes.
8. Correlate timestamps.

If many clients fail together, investigate shared RADIUS/AAA/NAC dependencies.
