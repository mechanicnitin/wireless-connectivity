---
name: wireless-investigation-correlation
version: 1.3.4
description: Parent methodology for complete wireless troubleshooting. Ensures the user's symptom does not constrain investigation to one failure domain.
---

# Wireless Investigation Correlation Skill

## Use

Load for wireless troubleshooting/diagnostic requests. This is broader than a single authentication, RF, DHCP, DNS, or association skill.

## Core principle

**Symptom is not failure domain.**

Examples:
- "slow" → inspect RF, retries, rates, roaming, AP load, DHCP latency, authentication/reconnect overhead, DNS/network path and shared dependencies as supported by telemetry.
- "can't authenticate" → verify association first, then authentication/authorization/RADIUS, and check scope across APs/WLAN.
- "keeps disconnecting" → correlate RF, roaming, PMF/SA Query, association, authentication, AP health, wired path and client-specific behavior.

## Required investigation domains

Use the orchestrator modules:
- incident-window
- client-investigation
- event-correlation
- rf-analysis
- authentication-analysis
- ap-correlation
- cross-client-analysis
- site-correlation
- network-path-analysis
- change-correlation
- rca-and-confidence

## Minimum evidence set

Before RCA, attempt to establish:
1. client identity/state
2. incident episodes
3. client timeline
4. APs involved
5. association/authentication state
6. IPv4/DHCP/ARP/DNS state
7. RF/roaming indicators
8. AP/wired health
9. cross-client scope
10. site/WLAN/SLE correlation
11. recent changes

If MCP cannot provide a domain, record a data gap rather than guessing.

## IPv4-only environment

Ignore IPv6/DHCPv6 unless explicitly requested.
