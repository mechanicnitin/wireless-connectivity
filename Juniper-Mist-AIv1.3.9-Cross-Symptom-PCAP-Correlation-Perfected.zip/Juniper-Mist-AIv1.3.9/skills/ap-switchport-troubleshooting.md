# AP Switchport Troubleshooting Skill

## Objective
Validate the wired path between a Juniper Mist AP and its connected switch.

## Checks
1. Identify AP, AP MAC, connected switch and interface.
2. Check interface admin/operational state, speed, duplex, uptime and flaps.
3. Check PoE state, power delivered, faults and recent PoE events.
4. Check LLDP neighbor identity and expected topology.
5. Check errors, CRC, drops, discards and utilization.
6. Validate access/trunk mode, native/allowed VLANs and AP management VLAN against site knowledge.
7. Check AP MAC learning on the expected port.
8. Check client MAC learning where relevant.
9. Check MAC movement/flapping.
10. Check ARP presence for clients that should already have an IP.

Never claim a condition that live data did not establish.
