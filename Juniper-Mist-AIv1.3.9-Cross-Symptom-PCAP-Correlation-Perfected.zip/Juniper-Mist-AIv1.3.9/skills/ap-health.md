# AP Health Skill

## Objective
Assess Juniper Mist AP availability and health before diagnosing downstream client issues.

## Checks
- Identify AP, site, model, and last-seen state.
- Check online/offline and cloud connectivity.
- Check uptime, reboots, disconnects and flaps.
- Review alarms, alerts, SLEs and health indicators.
- Check recent configuration/firmware changes.
- Compare with nearby APs.

## Interpretation
AP offline: investigate wired uplink, PoE, switchport and upstream connectivity.
Multiple APs affected: consider shared switching, site, authentication, DHCP, WAN or RF dependencies.

## Output
Report observed evidence, scope, confirmed failure point, likely cause, confidence and data gaps.
