# RF and SLE Analysis Skill

## Objective
Use multiple Juniper Mist RF and SLE indicators to identify wireless performance degradation and correlate them to the actual incident window.

## Checks
Where available:
- RSSI
- SNR
- noise floor
- channel
- channel width
- channel utilization
- interference
- retries/retransmissions
- packet loss
- PHY/MCS/rate information
- transmit power
- RRM channel/power changes
- roaming
- neighboring AP context
- client/AP SLEs and classifiers
- RF alarms/alerts

## Reasoning
- Compare affected versus healthy clients/APs.
- Correlate metrics with exact incident timestamps.
- Do not diagnose RF from one metric alone.
- Do not treat a degraded SLE as proof of causality without matching client/AP events.
- Distinguish marginal RF conditions from confirmed RF failure.

## IPv6
Ignore IPv6/DHCPv6 for this IPv4-only environment unless explicitly requested.
