# DNS Troubleshooting Skill

## Objective
Separate DNS failures from earlier connectivity failures.

## Preconditions
Do not begin DNS troubleshooting until usable IP connectivity is established.

## Checks
- Client IP configuration
- DNS server configuration where available
- DNS reachability
- Name-resolution symptoms
- Scope of impact
- Site/service dependencies

No IP means DHCP/network troubleshooting takes precedence.
Gateway unreachable means network connectivity takes precedence.
