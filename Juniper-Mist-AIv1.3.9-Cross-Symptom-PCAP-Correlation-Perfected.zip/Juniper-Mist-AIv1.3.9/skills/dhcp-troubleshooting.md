# DHCP Troubleshooting Skill

## Objective
Diagnose wireless client IP assignment after association and authentication.

## Checks
- Expected VLAN/subnet from site knowledge
- Client IP state
- DHCP success/failure indicators
- DHCP events/SLEs
- Gateway/scope information where available
- Another client on the same VLAN/AP for comparison

Auth succeeds + no IP: investigate DHCP path.
Multiple clients on one VLAN affected: investigate shared DHCP/relay/VLAN dependency.
